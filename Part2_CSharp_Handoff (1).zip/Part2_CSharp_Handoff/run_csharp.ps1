# AI-assisted convenience launcher; see ATTRIBUTION.md.
param([string]$Dotnet='', [int]$Port=5000)
$ErrorActionPreference='Stop'
if(-not $Dotnet){
 $candidate=Get-Command dotnet -ErrorAction SilentlyContinue
 if($candidate){
  $sdkList=& $candidate.Source --list-sdks
  if($sdkList -match '^10\.'){$Dotnet=$candidate.Source}
 }
 if(-not $Dotnet){
  $localSdk=Join-Path (Split-Path $PSScriptRoot -Parent) 'Group3_Complete\_tools\dotnet\dotnet.exe'
  if(Test-Path -LiteralPath $localSdk){$Dotnet=$localSdk}
 }
}
if(-not $Dotnet){throw 'Install a .NET 10 SDK, or supply -Dotnet with the full path to dotnet.exe.'}
$env:DOTNET_CLI_TELEMETRY_OPTOUT='1'
$env:DOTNET_NOLOGO='1'
Push-Location -LiteralPath $PSScriptRoot
try {
 & $Dotnet run --project (Join-Path $PSScriptRoot 'VariablesTypesStatementsSubprograms.csproj') --urls ('http://127.0.0.1:'+$Port)
 $runExitCode=$LASTEXITCODE
} finally {
 Pop-Location
}
exit $runExitCode
