// Origin: Hua's query model, AI-assisted revision; see ATTRIBUTION.md.
namespace EnrollmentSystem.Models;
public class StudentsQueryModel
{
    public string? name { get; set; } = "";
    public int page { get; set; } = 1;
    public int pageSize { get; set; } = 10;
}
