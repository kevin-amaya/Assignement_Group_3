// Origin: Hua's response model, AI-assisted revision; see ATTRIBUTION.md.
using EnrollmentSystem.DTOs;
namespace EnrollmentSystem.Models;

/// <summary>A separate response snapshot, so callers cannot mutate the stored DTO.</summary>
public class StudentsModel
{
    public int id { get; set; }
    public string firstName { get; set; } = "";
    public string lastName { get; set; } = "";
    public string name => $"{firstName} {lastName}";
    public string birthDay { get; set; } = "";
    public string gender { get; set; } = "";
    public string program { get; set; } = "";
    public int currentSemester { get; set; }
    public int numberOfCourses { get; set; }
    public double previousGPA { get; set; }

    public StudentsModel(StudentsDTO student)
    {
        id = student.id;
        firstName = student.firstName;
        lastName = student.lastName;
        birthDay = student.birthDay;
        gender = student.gender;
        program = student.program;
        currentSemester = student.currentSemester;
        numberOfCourses = student.numberOfCourses;
        previousGPA = student.previousGPA;
    }
}
