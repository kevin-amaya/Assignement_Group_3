// AI-generated validation module for team review and revision; see ATTRIBUTION.md.
using System.Globalization;
using EnrollmentSystem.DTOs;
namespace EnrollmentSystem.Models;

/// <summary>Validates a complete candidate before any stored record is changed.</summary>
public static class StudentValidator
{
    private static readonly string[] RequiredLabels =
        ["First name", "Last name", "Gender", "Program"];

    public static bool TryValidate(StudentInputModel input,
        out StudentsDTO student, out string error)
    {
        student = new StudentsDTO();
        string[] values = [input.firstName?.Trim() ?? "", input.lastName?.Trim() ?? "",
            input.gender?.Trim() ?? "", input.program?.Trim() ?? ""];
        for (int index = 0; index < values.Length; index++)
        {
            if (values[index].Length is < 1 or > 100)
            {
                error = $"{RequiredLabels[index]} must contain 1 to 100 characters.";
                return false;
            }
        }
        if (!DateOnly.TryParseExact(input.birthDay, "yyyy-MM-dd",
            CultureInfo.InvariantCulture, DateTimeStyles.None, out DateOnly birthDate)
            || birthDate > DateOnly.FromDateTime(DateTime.UtcNow))
        {
            error = "Date of birth must be a valid date in YYYY-MM-DD format and cannot be in the future.";
            return false;
        }
        if (input.currentSemester is null or < 1)
        {
            error = "Semester must be a whole number of 1 or greater.";
            return false;
        }
        if (input.numberOfCourses is null or < 0)
        {
            error = "Number of courses must be a whole number of 0 or greater.";
            return false;
        }
        if (input.previousGPA is null || !double.IsFinite(input.previousGPA.Value)
            || input.previousGPA.Value is < 0.0 or > 4.0)
        {
            error = "GPA must be a number between 0.0 and 4.0.";
            return false;
        }
        student.firstName = values[0];
        student.lastName = values[1];
        student.gender = values[2];
        student.program = values[3];
        student.birthDay = birthDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        student.currentSemester = input.currentSemester.Value;
        student.numberOfCourses = input.numberOfCourses.Value;
        student.previousGPA = input.previousGPA.Value;
        error = "";
        return true;
    }
}
