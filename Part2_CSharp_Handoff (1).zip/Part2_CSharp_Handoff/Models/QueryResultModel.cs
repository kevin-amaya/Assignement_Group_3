namespace EnrollmentSystem.Models
{
    public class QueryResultModel
    {
        public int totalNumber { get; set; }
        public int totalPages { get; set; }
        public int pageNumber { get; set; }
        public int pageSize { get; set; }

        public List<StudentsModel> students { get; set; } = new();
    }
}