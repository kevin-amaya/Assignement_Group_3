// AI-generated input contracts for team review and revision; see ATTRIBUTION.md.
namespace EnrollmentSystem.Models;

/// <summary>Null distinguishes missing input from valid numeric zero.</summary>
public class StudentInputModel
{
    public string? firstName { get; set; }
    public string? lastName { get; set; }
    public string? birthDay { get; set; }
    public string? gender { get; set; }
    public string? program { get; set; }
    public int? currentSemester { get; set; }
    public int? numberOfCourses { get; set; }
    public double? previousGPA { get; set; }
}
public class LoginInputModel
{
    public string? username { get; set; }
    public string? password { get; set; }
}
