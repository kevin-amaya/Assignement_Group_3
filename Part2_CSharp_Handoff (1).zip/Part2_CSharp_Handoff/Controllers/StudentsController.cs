// Origin: Hua's authenticated API, AI-assisted revision; see ATTRIBUTION.md.
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using EnrollmentSystem.Models;
using EnrollmentSystem.Services;
namespace EnrollmentSystem.Controller;

[Authorize(Roles = "Admin")]
[ApiController]
[Route("api/Students")]
public class StudentsController(StudentService studentService) : ControllerBase
{
    [HttpPost]
    public IActionResult InsertStudent([FromBody] StudentInputModel input)
    {
        var result = studentService.InsertStudent(input);
        return result.Key ? Ok(result) : BadRequest(result);
    }

    [HttpPut("{studentId}")]
    public IActionResult UpdateStudent([FromRoute] int studentId, [FromBody] StudentInputModel input)
    {
        var result = studentService.UpdateStudent(studentId, input);
        if (result.Key) return Ok(result);
        return result.Value == "Student not found." ? NotFound(result) : BadRequest(result);
    }

    [HttpGet("{studentId}")]
    public IActionResult GetStudent([FromRoute] int studentId)
    {
        var student = studentService.GetStudent(studentId);
        return student is null
            ? NotFound(new KeyValuePair<bool, string>(false, "Student not found."))
            : Ok(new KeyValuePair<bool, StudentsModel>(true, student));
    }

    [HttpDelete("{studentId}")]
    public IActionResult DeleteStudent([FromRoute] int studentId)
    {
        bool removed = studentService.DeleteStudent(studentId);
        var result = new KeyValuePair<bool, string>(removed,
            removed ? "Record removed." : "Student not found.");
        return removed ? Ok(result) : NotFound(result);
    }

    [HttpGet]
    public IActionResult GetStudents([FromQuery] StudentsQueryModel query)
    {
        if (query.page < 1 || query.pageSize is < 1 or > 100)
            return BadRequest(new KeyValuePair<bool, string>(false,
                "Page must be 1 or greater and page size must be between 1 and 100."));
        return Ok(new KeyValuePair<bool, QueryResultModel>(true, studentService.GetStudents(query)));
    }
}
