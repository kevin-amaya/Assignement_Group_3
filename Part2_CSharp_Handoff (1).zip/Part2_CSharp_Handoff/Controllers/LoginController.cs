// Origin: Hua's login controller, AI-assisted revision; see ATTRIBUTION.md.
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using EnrollmentSystem.Models;
using EnrollmentSystem.Services;
namespace EnrollmentSystem.Controller;

[ApiController]
[Route("api/Login")]
public class LoginController(LoginService loginService) : ControllerBase
{
    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> Login([FromBody] LoginInputModel input)
    {
        var result = await loginService.login(input.username ?? "", input.password ?? "");
        return result.Key ? Ok(result) : Unauthorized(result);
    }

    [Authorize(Roles = "Admin")]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Ok(new KeyValuePair<bool, string>(true, "Logout successful."));
    }
}
