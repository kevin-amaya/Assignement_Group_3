namespace EnrollmentSystem.Services
{
    public interface LoginService
    {
        Task<KeyValuePair<bool, string>> login(string username, string password);
    }
}
