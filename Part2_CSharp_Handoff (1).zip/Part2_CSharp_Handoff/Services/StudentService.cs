// Origin: Hua's service interface, AI-assisted revision; see ATTRIBUTION.md.
using EnrollmentSystem.Models;
namespace EnrollmentSystem.Services;

/// <summary>Interface calls dispatch to the registered implementation at runtime.</summary>
public interface StudentService
{
    KeyValuePair<bool, string> InsertStudent(StudentInputModel input);
    KeyValuePair<bool, string> UpdateStudent(int studentId, StudentInputModel input);
    StudentsModel? GetStudent(int studentId);
    bool DeleteStudent(int studentId);
    QueryResultModel GetStudents(StudentsQueryModel query);
}
