// Origin: Hua's student service, AI-assisted revision; see ATTRIBUTION.md.
using EnrollmentSystem.Models;
using EnrollmentSystem.Repositories;
namespace EnrollmentSystem.Services.Impl;

public class StudentServiceImpl(StudentsRepo studentsRepo) : StudentService
{
    public KeyValuePair<bool, string> InsertStudent(StudentInputModel input)
    {
        if (!StudentValidator.TryValidate(input, out var validated, out string error))
            return new(false, error);
        StudentsModel student = studentsRepo.InsertStudent(validated);
        return new(true, $"Added Student ID: {student.id}");
    }

    public KeyValuePair<bool, string> UpdateStudent(int studentId, StudentInputModel input)
    {
        if (studentsRepo.GetStudent(studentId) is null)
            return new(false, "Student not found.");
        if (!StudentValidator.TryValidate(input, out var validated, out string error))
            return new(false, error);
        return studentsRepo.UpdateStudent(studentId, validated)
            ? new(true, "Record updated.") : new(false, "Student not found.");
    }

    public StudentsModel? GetStudent(int studentId) => studentsRepo.GetStudent(studentId);
    public bool DeleteStudent(int studentId) => studentsRepo.DeleteStudent(studentId);
    public QueryResultModel GetStudents(StudentsQueryModel query) => studentsRepo.GetStudents(query);
}
