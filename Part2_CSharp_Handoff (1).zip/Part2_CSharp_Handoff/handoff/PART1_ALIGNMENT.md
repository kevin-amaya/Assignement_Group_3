# How the existing Part 1 actions map to C sharp

Manraj's supplied pseudocode remains the team's Part 1 work. This note explains
the implementation mapping; it does not replace his document.

| Pseudocode action | C sharp operation | Browser control |
| --- | --- | --- |
| AddStudent | POST /api/Students and InsertStudent | Add student |
| ModifyStudent | PUT /api/Students/{id} and UpdateStudent | Edit, then Save changes |
| RemoveStudent | DELETE /api/Students/{id} and DeleteStudent | Delete with confirmation |
| ViewStudents | GET /api/Students and GetStudents | Student records table and search/pages |
| Exit | Staff logout; server stops separately with Ctrl+C | Sign out |

The student data includes separate first/last names and numeric IDs beginning
at 1001, matching the supplied algorithm. The list remains the ordered container;
the ID dictionary provides direct lookup. C# uses permanent IDs rather than
positions in that list.

The web application uses browser events and HTTP routing to invoke the same
logical operations as the menu. GPA validation is applied on modification as
well as addition. Additional date, text and count validation improves robustness.
Part 3 should replicate this agreed implementation and its output contract.
