# C sharp reference API and output contract

Version: the prepared Part 2 handoff, based on Hua's commit `2d805f8`.
Examples assume a fresh process, so the first added ID is 1001.
Use this contract with the source and recorded C# results.

## Shared interface

Serve StudentsLogin.html, StudentsManagement.html, enrollment.js and enrollment.css
from `wwwroot`. `/` redirects to `/StudentsLogin.html`. GPA is displayed with
JavaScript `toFixed(2)`. The empty table says `Empty list.`. Empty results display
`Page 1 of 1`, while the API reports zero result pages.

## Authentication

POST `/api/Login` with Content-Type application/json:

```json
{"username":"admin","password":"admin"}
```

Success: HTTP 200, a staff session cookie, and:

```json
{"Key":true,"Value":"Login successful."}
```

Wrong credentials: HTTP 401 with `{"Key":false,"Value":"Invalid username or password."}`.
Unauthenticated enrollment calls: HTTP 401 with `{"Key":false,"Value":"Please sign in."}`.
Sessions are valid for a maximum of eight hours. Use HttpOnly and SameSite Lax.
Cookie names, encryption and opaque token contents are implementation details.

POST `/api/Login/logout` while signed in: HTTP 200,
`{"Key":true,"Value":"Logout successful."}`, and clear the browser's session cookie.
Student records remain during this server run. Restarting clears records and sign-in state.

## Routes

| Method | Route | Successful Value | Other documented results |
| --- | --- | --- | --- |
| POST | /api/Students | Added Student ID: followed by the ID | 400 invalid input |
| PUT | /api/Students/{id} | Record updated. | 400 invalid input; 404 missing student |
| DELETE | /api/Students/{id} | Record removed. | 404 missing student |
| GET | /api/Students/{id} | Student object | 404 missing student |
| GET | /api/Students | Query result object | 400 invalid query |

All successful student calls above return HTTP 200 with `Key: true`.
Failures return `Key: false` and a message string in Value.
Missing student message: `Student not found.`
An unknown PUT never inserts a new record.

## Add and modify body

```json
{
  "firstName":"Ada",
  "lastName":"Lovelace",
  "birthDay":"2000-02-29",
  "gender":"Woman",
  "program":"Software Development",
  "currentSemester":1,
  "numberOfCourses":5,
  "previousGPA":3.7
}
```

Send the complete body on PUT, with the target ID in the URL. Do not accept
the body as a request to change ID. A valid first POST returns:

```json
{"Key":true,"Value":"Added Student ID: 1001"}
```

GET `/api/Students/1001` then returns:

```json
{
  "Key":true,
  "Value":{
    "id":1001,"firstName":"Ada","lastName":"Lovelace","name":"Ada Lovelace",
    "birthDay":"2000-02-29","gender":"Woman","program":"Software Development",
    "currentSemester":1,"numberOfCourses":5,"previousGPA":3.7
  }
}
```

IDs start at 1001 and increase once per successful add. Identical identifying
fields do not overwrite another student. Deleting a record does not reuse its
ID. Returned `name` is derived as firstName + one space + lastName.

## Validation and messages

First parse an object with string text fields, integer counts and numeric GPA.
Reject malformed JSON, non-string text, quoted numbers, fractional counts,
boolean counts and counts outside signed 32-bit range with HTTP 400 and
`Invalid request data.`. Missing/null fields then follow the domain rules below.

Validate trimmed first name, last name, gender and program in that order; then
date of birth, semester, course count and GPA. Missing ID is checked before
domain validation for PUT, after the typed JSON body has been parsed.

| Field | Rule | Exact error Value |
| --- | --- | --- |
| firstName | 1–100 UTF-16 units after trimming | First name must contain 1 to 100 characters. |
| lastName | 1–100 UTF-16 units after trimming | Last name must contain 1 to 100 characters. |
| gender | Required free text, 1–100 UTF-16 units | Gender must contain 1 to 100 characters. |
| program | Required free text, 1–100 UTF-16 units | Program must contain 1 to 100 characters. |
| birthDay | Real YYYY-MM-DD date, not after current UTC date | Date of birth must be a valid date in YYYY-MM-DD format and cannot be in the future. |
| currentSemester | Required integer, 1 through 2147483647 | Semester must be a whole number of 1 or greater. |
| numberOfCourses | Required integer, 0 through 2147483647 | Number of courses must be a whole number of 0 or greater. |
| previousGPA | Required finite JSON number from 0.0 through 4.0 | GPA must be a number between 0.0 and 4.0. |

Every rejected edit leaves the previous student record unchanged.
The GPA range follows Manraj's supplied algorithm; the semester/course rules
are documented prototype choices, not a claim about all institutional policy.

## Listing and pagination

GET `/api/Students?name=Ada&page=1&pageSize=10`.
Defaults: name is empty, page is 1, pageSize is 10. Search includes records whose
derived name contains the filter, with case-sensitive comparison. Preserve
insertion order. Page must be at least 1 and pageSize must be from 1 through 100.

For valid integers outside the permitted page range, HTTP 400 Value is:
`Page must be 1 or greater and page size must be between 1 and 100.`
Noninteger/out-of-32-bit query values return `Invalid request data.`.

```json
{
  "Key":true,
  "Value":{
    "totalNumber":1,"totalPages":1,"pageNumber":1,"pageSize":10,
    "students":[{"id":1001,"firstName":"Ada","lastName":"Lovelace","name":"Ada Lovelace","birthDay":"2000-02-29","gender":"Woman","program":"Software Development","currentSemester":1,"numberOfCourses":5,"previousGPA":3.7}]
  }
}
```

totalPages is ceiling(totalNumber/pageSize). A requested page above the final
page is clamped to it. No matches gives totalNumber 0, totalPages 0, pageNumber 1
and students []. There is no persistence requirement; data resets on restart.
