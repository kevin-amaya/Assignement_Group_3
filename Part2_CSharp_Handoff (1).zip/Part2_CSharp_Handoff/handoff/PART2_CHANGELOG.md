# What changed from Hua's supplied C sharp project

Base: https://github.com/huasuoworld/VariablesTypesStatementsSubprograms
at `2d805f88fb169776d2fc2dc83258884136845553`, checked November 16, 2026.
The layered controller/service/repository structure is retained.

| Area | Supplied version | Prepared Part 2 revision |
| --- | --- | --- |
| Student identity | Hash based on name, birth date, gender and program | Permanent integer ID, starting at 1001 |
| Modification | Route identifier unused; changing identifying fields could insert another student | Route ID selects the record; every editable field can change while ID stays fixed |
| Names | Combined name field | Separate required first/last names and derived display name |
| Validation | Typed properties with limited browser restrictions | Complete server validation on both add and edit; invalid edits make no partial change |
| Removal | Dictionary stored list positions | Dictionary maps IDs to objects; list removal cannot invalidate remaining ID keys |
| Missing records | Lookup could throw a generic exception | Controlled 404 result with Student not found. |
| Authentication errors | Bad login could surface as an exception | Controlled 401 result; staff enrollment authorization and logout |
| Response isolation | Stored objects could be exposed by some repository operations | Separate student response snapshots |
| Runtime state | Singleton collection storage | In-memory collection state and ephemeral authentication keys; restart resets data/sign-in |
| Browser assets | External style/font resources and unused scripts | Self-contained pages, exact fields and safe text insertion, reusable by Part 3 |
| Dependencies | Optional Swagger NuGet dependency | Framework-only .NET 10 application |
| Demonstration concepts | Existing classes, collections and methods | Explicit ref ID increment, out validation results, arrays, scopes and interface dispatch documented |
| Repository contents | Build outputs and unused alternate repository | Source-focused handoff; generated files excluded and unused alternate source removed |

The contract deliberately differs from the original GitHub API in ID handling,
name fields and JSON-body login. Kevin should use the attached source and API
contract together. The GitHub repository itself has not been changed.

The patch lists source and handoff changes for review. Original code attribution
and AI-assisted revisions are documented in ATTRIBUTION.md and file comments.
