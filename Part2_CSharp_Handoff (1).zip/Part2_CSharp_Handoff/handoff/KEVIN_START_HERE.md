# Kevin's Part 3 starting guide

Your task is to implement the enrollment behaviour in Python and match the
finished C# program's visible output. The attached C# source is the reference
revision for this handoff; the original GitHub version has different field and
ID behaviour. Read API_CONTRACT.md alongside this guide.

## Quickest route to matching output

Reuse all four files in `wwwroot` unchanged. They already contain the labels,
forms, record table, prompts, error handling and GPA formatting. Build a Python
backend that serves those files and answers the documented `/api` routes.
Because the browser requests relative URLs, it will call whichever backend
serves the pages. You do not need to rewrite the HTML, CSS or JavaScript.

You may choose a Python framework or a standard-library server. No specific
framework is required. Run your version on port 5001 so it can be checked beside
C# on port 5000. Cookies belong to a host rather than a port: give your own session
cookie a distinct name to avoid confusion when both versions are open.

## Suggested implementation order

1. Define a student record with ID, separate first/last names, date of birth,
   gender, previous GPA, semester, program and course count. Keep display name
   derived from the two names. See DTOs/StudentsDTO.cs.
2. Create a list for insertion order and a dictionary mapping permanent integer
   IDs to the same student objects. Start the next ID at 1001. Increment it only
   after a valid add; do not reuse deleted IDs during the run.
3. Implement one complete validation function and call it for both add and edit.
   Validate a candidate before changing the stored object. Match validation order
   and messages in Models/StudentValidator.cs and API_CONTRACT.md.
4. Add modular insert, modify, get, list/query and remove operations. Use the ID
   from the URL to modify existing records; an unknown PUT must return not found.
   Any field, including name, gender, birth date and program, may change while ID stays fixed.
5. Add staff login/logout and an administrative session cookie. Keep enrollment
   APIs protected. The demonstration account is admin/admin; students do not enroll themselves.
6. Serve `wwwroot`, implement the routes and response envelopes, and check the
   browser interface. Dates and JSON keys must match the documented contract.
7. Run the contract tool against a fresh Python server. Use the C# result JSON
   as the reference and fix differences before recording final output parity.

## Python details that can cause differences

- Hints such as `semester: int` do not validate JSON at runtime. Check actual types.
- Python bool is a subclass of int; reject True/False as semester or course counts.
- C# uses signed 32-bit integers for IDs/counts. Apply the documented input bounds.
- C# string.Length counts UTF-16 units. The 100-unit text limit is not always
  identical to Python len(text) for supplementary characters.
- The JSON GPA must be numeric and finite, from 0 through 4. Do not accept a
  quoted number such as "3.5". The shared browser displays two decimal places.
- Parse a real date, require YYYY-MM-DD, and compare with the current UTC date.
  The example 2000-02-29 is valid; 2025-02-29 is not.
- Preserve insertion order, case-sensitive name filtering and the documented
  empty-list/page rules. Return independent snapshots rather than exposing
  mutable storage to callers.
- Return exactly `Key` and `Value` for the envelope. Keep capitalization and
  message punctuation. Your cookie bytes and HTTP headers need not match .NET.

## Check against the C sharp reference

Start your fresh Python server on 127.0.0.1:5001. From the handoff folder run:

```powershell
python tools/verify_contract.py --base-url http://127.0.0.1:5001 --reference test_evidence/CSharp_contract_results.json --output test_evidence/Kevin_contract_results.json
```

This runs **92 checks** against your live server, including the exact JSON
responses and byte-identical browser files. It does not need .NET in external
mode. It creates fictional records; use a fresh, dedicated process with no
records you need to keep. The initial empty-list assertion runs before adds.

The C# reference also includes **four restart checks**, for 96 in its managed run.
For Python, verify those separately: stop the process, start it again, sign in,
confirm no records remain and confirm the first valid add gets ID 1001 again.

The readable C# result table and JSON include case IDs, requests, HTTP status,
response content and browser-file hashes. Keep your Python result file so the
team can compare the actual implementations later in Part 4.

## Done checklist

- Every required field supports add, view and modification.
- Program/name edits retain the ID and do not increase the record count.
- Invalid add/edit values are rejected without partial changes.
- Deleting first/middle/last records leaves remaining lookups correct.
- All 92 live-server checks pass; four restart checks are recorded separately.
- Browser labels, messages, table values and GPA formatting match C#.
- Your functions, names, comments and assistance attribution are clear.
- You can explain your types, scopes, containers, object sharing and argument passing.
