# GitHub handoff workflow

The prepared C# revision builds on Hua's original repository and commit
`2d805f88fb169776d2fc2dc83258884136845553`. Use a branch called
`adlin-part2-fixes` in that same repository for the Part 2 handoff.
Keep main unchanged until the team reviews and merges the changes.

## Current publication status

The branch was prepared locally with Hua's three original commits preserved.
The connected GitHub access rejected branch creation with HTTP 403,
`Resource not accessible by integration`. No remote branch or pull request
was created and Hua's main was not changed. Access must be resolved before
a working GitHub branch link can be shared. The source ZIP is usable meanwhile.

The separate local Git review folder and .bundle file preserve the prepared
branch and original history. They are not extra assignment parts. No personal
access token or password is included. The commit message and source comments
disclose AI assistance; the team should record its actual review and revisions.

## Publishing after access is fixed

Using an installed Git client, from the prepared Part2_Git_Review folder:

```powershell
git status
git log --oneline --all -4
git push origin adlin-part2-fixes
```

If using the bundle on another computer instead:

```powershell
git clone -b adlin-part2-fixes Part2_adlin-part2-fixes.bundle Part2_Git_Review
cd Part2_Git_Review
git remote set-url origin https://github.com/huasuoworld/VariablesTypesStatementsSubprograms.git
git push origin adlin-part2-fixes
```

These commands push the named branch, not main. GitHub still requires write
permission. Check that an invitation to Adlin-F was accepted and that the
chosen GitHub connection can write to this repository. Browser sign-in alone
does not prove either condition.

After a successful push, open the actual branch page and verify the source
before sharing its link. Kevin should read KEVIN_START_HERE.md and API_CONTRACT.md
on that branch. Send Manraj's original Part 1 document separately. A pull request
can then show Hua the changes for review; merging is a separate team decision.
