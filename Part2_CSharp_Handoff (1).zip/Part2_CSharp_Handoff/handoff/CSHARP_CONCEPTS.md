# Part 2 concepts in the actual C sharp code

| Required concept | Example and location | What it demonstrates |
| --- | --- | --- |
| Meaningful variable names | studentList, studentsById, nextId, storedStudent in Repositories/StudentsRepo.cs | Names identify records, storage and permanent identity rather than ambiguous list positions. |
| Data types | int, double and string in DTOs/StudentsDTO.cs; bool status; string[] arrays in Models/StudentValidator.cs | Primitive values and grouped/composite types represent the required fields and validation labels. |
| Static type binding | var matching in GetStudents; typed properties and method signatures | var is compiler inference, not dynamic typing. A resizable list is not dynamically typed. |
| Runtime binding | StudentService interface resolved to StudentServiceImpl in Program.cs | Calls through the service interface dispatch to the implementation at runtime. This differs from type binding. |
| Scope and lifetime | Private repository fields; local assignedId; block-local validation variables; singleton registration | Instance state persists across requests; local and block visibility remain limited. Singleton lifetime does not make a field a global variable. |
| Referencing | Both collections hold the same StudentsDTO; UpdateStudent mutates that object | Aliases observe the same edit. GetStudent constructs a separate StudentsModel response snapshot. |
| Pass by value | int studentId parameters and ordinary object parameters | The integer value is copied; a class parameter receives a reference copied by value. Rebinding that parameter would not rebind its caller's variable. |
| Pass by reference | AllocateId(ref int counter), called with ref nextId | Updating counter changes the actual repository counter. |
| Output parameters | TryValidate(input, out var validated, out string error) | The method supplies a validated candidate or a clear error to the caller. |
| Conversions | (int)Math.Ceiling((double)total / query.pageSize) | Real division and upward rounding produce the integer page count. |
| Decisions and repetition | Validation if/for statements, repository filtering, browser record rendering | Branches handle validity/not-found cases; loops and queries process collections. |
| Subprograms and modules | Controllers, service interface/implementation, repository and validator | Separate responsibilities support understandable add/modify/remove/view operations. |
| Documentation and tests | Origin comments, ATTRIBUTION.md, tools/verify_contract.py and test_evidence | Source provenance, design choices, expected results and actual checks are reviewable. |

Public response property names retain the existing JSON-oriented camelCase.
Methods such as InsertStudent and AllocateId use PascalCase. Avoid explaining
all class arguments as explicit ref arguments; only parameters declared ref/out
use those C# mechanisms.
