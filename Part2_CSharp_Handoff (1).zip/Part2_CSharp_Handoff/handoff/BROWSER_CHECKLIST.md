# Final browser check for the team

Status: not yet recorded. Browser automation was unavailable during preparation.
The build and API checks passed; this checklist covers the actual browser controls.

Start a fresh C# process, open StudentsLogin.html, and use fictional data.

1. Try admin with an incorrect password. Confirm the error stays on the login page.
2. Sign in with admin/admin. Confirm the empty records table and Add student form.
3. Add Ada Lovelace, 2000-02-29, Woman, GPA 3.70, semester 1,
   Software Development, five courses. Confirm ID 1001 and every displayed field.
4. Edit the record. Change first/last names, date, gender, program, semester,
   course count and GPA. Save; confirm every change, the same ID and one record.
5. Try an invalid GPA and date. Confirm the form or server rejects the input and
   the stored record is unchanged. Cancel editing and confirm the add form returns.
6. Add another fictional record. Search for its name, then clear the search.
   Confirm the expected rows return. Check page controls after adding 11 records.
7. Delete a fictional record, first cancelling the confirmation and then accepting.
   Confirm only the selected row is removed and the other row remains editable.
8. Sign out. Reopen StudentsManagement.html; confirm it returns to sign-in.
9. Stop and restart the server. Sign in; confirm the list is empty again.
10. Open the page in a narrow window and confirm all form fields are usable;
    the records table may scroll horizontally.

Record the person/date, browser, outcome and any corrections here after checking:

| Person and date | Browser | Outcome / issue corrected |
| --- | --- | --- |
| To be completed by the team | | |
