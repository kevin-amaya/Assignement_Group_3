// Origin: Hua's DTO, AI-assisted revision; see ATTRIBUTION.md.
namespace EnrollmentSystem.DTOs;

/// <summary>Mutable student data stored in memory for one server run.</summary>
public class StudentsDTO
{
    public int id { get; set; }
    public string firstName { get; set; } = "";
    public string lastName { get; set; } = "";
    public string name => $"{firstName} {lastName}";
    public string birthDay { get; set; } = "";
    public string gender { get; set; } = "";
    public string program { get; set; } = "";
    public int currentSemester { get; set; }
    public int numberOfCourses { get; set; }
    public double previousGPA { get; set; }
}
