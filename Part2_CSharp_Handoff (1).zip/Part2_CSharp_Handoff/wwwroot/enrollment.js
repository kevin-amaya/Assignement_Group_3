// AI-assisted revision of Hua's browser enrollment flow; see ATTRIBUTION.md.
// Both backends serve this exact file. Student values are inserted with textContent.
"use strict";
const byId = id => document.getElementById(id);

function message(id, text = "", isError = false) {
    const element = byId(id);
    element.textContent = text;
    element.className = "message" + (isError ? " error" : "");
    element.hidden = !text;
}

async function request(url, method = "GET", body) {
    const response = await fetch(url, {
        method, credentials: "same-origin",
        headers: body === undefined ? {"Accept":"application/json"} :
            {"Accept":"application/json","Content-Type":"application/json"},
        ...(body === undefined ? {} : {body:JSON.stringify(body)})
    });
    const result = await response.json();
    if (!response.ok || result.Key !== true) {
        const error = new Error(typeof result.Value === "string" ? result.Value : "Request failed.");
        error.status = response.status;
        throw error;
    }
    return result.Value;
}

if (document.body.dataset.page === "login") {
    byId("login-form").addEventListener("submit", async event => {
        event.preventDefault();
        const form = event.currentTarget;
        if (!form.reportValidity()) return;
        byId("login-button").disabled = true;
        message("login-message");
        try {
            await request("/api/Login","POST",{
                username:form.elements.username.value,
                password:form.elements.password.value
            });
            window.location.href = "/StudentsManagement.html";
        } catch (error) {
            message("login-message",error.message,true);
        } finally {
            byId("login-button").disabled = false;
        }
    });
}

if (document.body.dataset.page === "management") {
    const state = {page:1, pageSize:10, filter:"", editingId:null, totalPages:0};
    const form = byId("student-form");
    form.elements.birthDay.max = new Date().toISOString().slice(0,10);

    function resetForm() {
        form.reset();
        state.editingId = null;
        byId("form-title").textContent = "Add student";
        byId("save-button").textContent = "Add student";
        byId("cancel-button").hidden = true;
    }

    async function editStudent(id) {
        message("form-message");
        try {
            const student = await request("/api/Students/" + id);
            for (const [name,value] of Object.entries(student)) {
                const field = form.elements.namedItem(name);
                if (field) field.value = value;
            }
            state.editingId = student.id;
            byId("form-title").textContent = "Edit student " + student.id;
            byId("save-button").textContent = "Save changes";
            byId("cancel-button").hidden = false;
            form.scrollIntoView({behavior:"smooth",block:"center"});
        } catch (error) {message("form-message",error.message,true);}
    }

    async function deleteStudent(id) {
        if (!window.confirm("Delete student " + id + "?")) return;
        try {
            const text = await request("/api/Students/" + id,"DELETE");
            if (state.editingId === id) resetForm();
            await loadStudents();
            message("list-message",text);
        } catch (error) {message("list-message",error.message,true);}
    }

    function renderStudents(students) {
        const rows = byId("student-rows");
        rows.replaceChildren();
        if (!students.length) {
            const cell = rows.insertRow().insertCell();
            cell.colSpan = 9;
            cell.className = "empty";
            cell.textContent = "Empty list.";
            return;
        }
        for (const student of students) {
            const row = rows.insertRow();
            for (const value of [student.id,student.name,student.birthDay,student.gender,
                student.program,student.currentSemester,student.numberOfCourses,
                Number(student.previousGPA).toFixed(2)]) {
                row.insertCell().textContent = String(value);
            }
            const actions = row.insertCell();
            actions.className = "actions";
            for (const [label,style,action] of [
                ["Edit","secondary",() => editStudent(student.id)],
                ["Delete","danger",() => deleteStudent(student.id)]]) {
                const button = document.createElement("button");
                button.type = "button";
                button.textContent = label;
                button.className = "small " + style;
                button.addEventListener("click",action);
                actions.append(button);
            }
        }
    }

    async function loadStudents() {
        message("list-message");
        byId("refresh-button").disabled = true;
        try {
            const query = new URLSearchParams({
                page:String(state.page),pageSize:String(state.pageSize),name:state.filter
            });
            const result = await request("/api/Students?" + query);
            state.page = result.pageNumber;
            state.totalPages = result.totalPages;
            renderStudents(result.students);
            byId("records-summary").textContent = result.totalNumber + " student record" +
                (result.totalNumber === 1 ? "" : "s");
            byId("page-label").textContent = "Page " + state.page + " of " +
                Math.max(1,state.totalPages);
            byId("previous-page").disabled = state.page <= 1;
            byId("next-page").disabled = state.page >= state.totalPages;
        } catch (error) {
            if (error.status === 401 || error.status === 403) {
                window.location.href = "/StudentsLogin.html";
                return;
            }
            message("list-message",error.message,true);
        } finally {byId("refresh-button").disabled = false;}
    }

    form.addEventListener("submit",async event => {
        event.preventDefault();
        if (!form.reportValidity()) return;
        const fields = new FormData(form);
        const student = Object.fromEntries(fields);
        for (const key of ["currentSemester","numberOfCourses","previousGPA"]) {
            student[key] = Number(student[key]);
        }
        byId("save-button").disabled = true;
        message("form-message");
        try {
            const editing = state.editingId !== null;
            const text = await request("/api/Students" +
                (editing ? "/" + state.editingId : ""),editing ? "PUT" : "POST",student);
            resetForm();
            message("form-message",text);
            state.page = 1;
            await loadStudents();
        } catch (error) {message("form-message",error.message,true);}
        finally {byId("save-button").disabled = false;}
    });
    byId("cancel-button").addEventListener("click",() => {resetForm();message("form-message");});
    byId("search-form").addEventListener("submit",event => {
        event.preventDefault();
        state.filter = byId("search-name").value.trim();
        state.page = 1;
        loadStudents();
    });
    byId("refresh-button").addEventListener("click",loadStudents);
    byId("previous-page").addEventListener("click",() => {state.page--;loadStudents();});
    byId("next-page").addEventListener("click",() => {state.page++;loadStudents();});
    byId("logout-button").addEventListener("click",async () => {
        try {await request("/api/Login/logout","POST");window.location.href="/StudentsLogin.html";}
        catch (error) {message("list-message",error.message,true);}
    });
    loadStudents();
}
