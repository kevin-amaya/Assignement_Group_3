# Part 2 C sharp enrollment handoff

This package finishes the C# enrollment prototype based on Hua's project and
provides a clear baseline for Kevin's Part 3 Python implementation.

## Start the C sharp application

Requirement: **.NET 10 SDK**, not only the .NET runtime. From this folder run:

```powershell
dotnet run --urls http://127.0.0.1:5000
```

Open http://127.0.0.1:5000/StudentsLogin.html. The staff demonstration account is
`admin` / `admin`. `StudentsManagement.html` provides add, edit, delete, search
and view operations after sign-in. The UI includes every required student field.
There are no external NuGet packages, JavaScript libraries or web fonts to install.

On Adlin's current computer, `./run_csharp.ps1` can use the local test SDK already
downloaded in the sibling Group3_Complete folder. On another computer it uses
the installed .NET 10 SDK, or accepts `-Dotnet <path-to-dotnet.exe>`.

## What is finished in this C sharp revision

- A permanent integer ID starts at 1001 and remains unchanged when any student
  field, including program or name, is edited.
- First and last names are stored separately; all required enrollment fields
  can be added, viewed and modified.
- Complete input validation runs before either addition or modification.
  An invalid edit leaves the stored record unchanged.
- List/dictionary storage supports repeated operations during one run. Removing
  a record does not break IDs or lookups for the remaining records.
- Missing students, invalid inputs and failed login receive controlled results.
- Staff authentication protects enrollment APIs. Logout clears the current
  browser's session cookie. Records reset when the server restarts.
- Meaningful types, arrays, scope, interface dispatch, references, `ref`/`out`,
  conversions, branching and subprograms are documented in the code and concept map.

## What Kevin receives for Part 3

Start with **[handoff/KEVIN_START_HERE.md](handoff/KEVIN_START_HERE.md)**.
It gives the implementation order and explains how to reuse `wwwroot` unchanged.
**[handoff/API_CONTRACT.md](handoff/API_CONTRACT.md)** defines every route, field,
message and example. The recorded C# results include complete requests and
responses for comparison.

The only Python file in this handoff is an implementation-independent **test
utility**, `tools/verify_contract.py`. It does not implement enrollment or
complete Kevin's Part 3. The backup enrollment implementation and backup Part 4
are kept in the separate local preparation folder.

## Run the C sharp contract checks

Optional test-tool requirement: Python 3.10 or later; no pip packages are needed.
Normal use of the C# application does not require Python.

```powershell
python tools/verify_contract.py --dotnet dotnet --output test_evidence/CSharp_contract_results.json
```

The runner builds C#, starts a dedicated local server with fictional records,
checks the public API and browser assets, verifies restart behaviour and stops
its own server. It records 96 checks. See the included result JSON, readable
result table and build log in `test_evidence` for this prepared revision's run.

Kevin can run the same tool against his fresh Python server on another port:

```powershell
python tools/verify_contract.py --base-url http://127.0.0.1:5001 --reference test_evidence/CSharp_contract_results.json --output test_evidence/Kevin_contract_results.json
```

External-server mode performs 92 checks without requiring .NET. Four checks that
restart a server are omitted because the runner does not control Kevin's process;
his restart/reset checklist is in the handoff guide. Use a fresh dedicated server:
the tests add, edit and remove fictional student records and expect an empty start.

## Files to review and share

- `handoff/KEVIN_START_HERE.md`: the Part 3 starting guide.
- `handoff/API_CONTRACT.md`: exact interface and output contract.
- `handoff/PART2_CHANGELOG.md`: changes from Hua's supplied GitHub version.
- `handoff/CSHARP_CONCEPTS.md`: assignment concepts mapped to the actual source.
- `handoff/PART1_ALIGNMENT.md`: how the existing pseudocode actions map to C#.
- `handoff/GITHUB_HANDOFF.md`: local branch/history and the publication access issue.
- `handoff/BROWSER_CHECKLIST.md`: a short final UI check for the team; interactive
  automation was unavailable during preparation.
- `handoff/MESSAGE_TO_TEAM.md`: a ready-to-edit handoff message; it has not been sent.
- `handoff/Changes_from_Hua_original.patch`: reviewable C# handoff changes.
- `SOURCE_MANIFEST.json`: hashes identifying this handoff revision.
- `ATTRIBUTION.md`: source origins, AI assistance and the student revision record.

Hua's GitHub main branch was checked on November 16, 2026 and still points to
`2d805f88fb169776d2fc2dc83258884136845553`. This package is a **local revision**;
it has not been pushed to that repository. Review the changes with Hua and use
the same agreed C# revision when Kevin checks his Python output.
