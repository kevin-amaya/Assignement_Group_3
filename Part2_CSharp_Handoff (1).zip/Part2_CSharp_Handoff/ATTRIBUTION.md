# Part 2 source and assistance record

Hua supplied the original C# project at:
https://github.com/huasuoworld/VariablesTypesStatementsSubprograms

Base commit: `2d805f88fb169776d2fc2dc83258884136845553`.
The controller/service/repository organization, DTO/model separation, collection
storage, cookie login and browser CRUD flow provided the starting point.
Manraj supplied the original Part 1 pseudocode. That work is separate from this
C# handoff and has not been replaced by this package.

ChatGPT/Codex prepared the local revision at Adlin's request. File comments mark
modified or generated sections. AI-assisted changes include permanent IDs,
separate names, full-field edits, validation, response snapshots, controlled API
results, the updated browser pages and the contract test utility. The removed
alternate repository and unused scripts are identified in the change list/patch.

The contract test is a verification tool, not Kevin's enrollment implementation.
No Python enrollment program, Part 4 comparison or peer-review document is
included in this handoff.

Retain source comments and record actual student changes below. The assignment
requires distinguishing student contributions from modified external-tool code.
Reviewing this preparation is not proof that a student independently authored
all generated sections.

| Member | Actual work or revision | Evidence |
| --- | --- | --- |
| Hua | Original C# repository and startup instructions | Base commit above |
| Adlin Firdaus | Record personally reviewed/modified C# sections and tests actually run | Add paths, explanations and final commits |
| Shared Part 2 work | Record reviewed fixes, agreed design and source changes | Add confirmed contributors and commits |
