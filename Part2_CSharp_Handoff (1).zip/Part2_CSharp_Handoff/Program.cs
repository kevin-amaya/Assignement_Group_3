// Origin: Hua's ASP.NET startup, AI-assisted revision; see ATTRIBUTION.md.
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.DataProtection;
using EnrollmentSystem.Repositories;
using EnrollmentSystem.Services.Impl;
using EnrollmentSystem.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.PropertyNamingPolicy = null;
    options.JsonSerializerOptions.NumberHandling = System.Text.Json.Serialization.JsonNumberHandling.Strict;
});
builder.Services.Configure<ApiBehaviorOptions>(options =>
    options.InvalidModelStateResponseFactory = context => new BadRequestObjectResult(
        new KeyValuePair<bool, string>(false, "Invalid request data.")));
builder.Services.AddHttpContextAccessor();
// Session keys are ephemeral, like the student records; no key files are written.
builder.Services.AddDataProtection().UseEphemeralDataProtectionProvider();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = false;
        options.Events.OnRedirectToLogin = async context =>
        {
            context.Response.StatusCode = 401;
            await context.Response.WriteAsJsonAsync(new { Key = false, Value = "Please sign in." },
                new System.Text.Json.JsonSerializerOptions());
        };
        options.Events.OnRedirectToAccessDenied = async context =>
        {
            context.Response.StatusCode = 403;
            await context.Response.WriteAsJsonAsync(new { Key = false, Value = "Administrator access is required." },
                new System.Text.Json.JsonSerializerOptions());
        };
    });
builder.Services.AddAuthorization();
builder.Services.AddSingleton<StudentsRepo>();
builder.Services.AddScoped<LoginRepo>();
builder.Services.AddScoped<StudentService, StudentServiceImpl>();
builder.Services.AddScoped<LoginService, LoginServiceImpl>();

var app = builder.Build();
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.MapGet("/", () => Results.Redirect("/StudentsLogin.html"));
app.MapControllers();
app.Run();
