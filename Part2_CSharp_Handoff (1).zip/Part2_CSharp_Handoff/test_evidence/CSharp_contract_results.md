# Enrollment contract test results

Overall: PASS
Checks: 96
Restart checks: performed

| ID | Case | Result |
| --- | --- | --- |
| C001 | Unauthorized enrollment access | PASS |
| C002 | Wrong password | PASS |
| C003 | Staff login | PASS |
| C004 | Empty collection | PASS |
| C005 | Add required fields | PASS |
| C006 | Retrieve all student fields | PASS |
| C007 | Same identifying fields get another ID | PASS |
| C008 | Edit program and name by stable ID | PASS |
| C009 | Edited record retains ID | PASS |
| C010 | Other student is unchanged | PASS |
| C011 | Reject invalid edit | PASS |
| C012 | Rejected edit leaves the whole record unchanged | PASS |
| C013 | Unknown ID GET | PASS |
| C014 | Unknown ID PUT | PASS |
| C015 | Unknown ID DELETE | PASS |
| C016 | Malformed JSON | PASS |
| C017 | Wrong JSON type or range currentSemester '2' | PASS |
| C018 | Wrong JSON type or range numberOfCourses 2.5 | PASS |
| C019 | Wrong JSON type or range numberOfCourses True | PASS |
| C020 | Wrong JSON type or range previousGPA '3.5' | PASS |
| C021 | Wrong JSON type or range numberOfCourses 2147483648 | PASS |
| C022 | Wrong JSON type or range firstName 123 | PASS |
| C023 | Required text validation firstName length 3 | PASS |
| C024 | Required text validation firstName length 101 | PASS |
| C025 | Required text validation lastName length 3 | PASS |
| C026 | Required text validation lastName length 101 | PASS |
| C027 | Required text validation gender length 3 | PASS |
| C028 | Required text validation gender length 101 | PASS |
| C029 | Required text validation program length 3 | PASS |
| C030 | Required text validation program length 101 | PASS |
| C031 | Invalid date 2025-02-29 | PASS |
| C032 | Invalid date 2000-02-30 | PASS |
| C033 | Invalid date 01/02/2000 | PASS |
| C034 | Invalid date 2026-11-17 | PASS |
| C035 | Valid GPA boundary 0.0 | PASS |
| C036 | Valid GPA boundary 4.0 | PASS |
| C037 | Invalid GPA -0.001 | PASS |
| C038 | Invalid GPA 4.001 | PASS |
| C039 | Invalid GPA None | PASS |
| C040 | Negative course count | PASS |
| C041 | Zero semester | PASS |
| C042 | Pagination validation page=0 | PASS |
| C043 | Pagination validation page=-1 | PASS |
| C044 | Pagination validation pageSize=0 | PASS |
| C045 | Pagination validation pageSize=101 | PASS |
| C046 | Invalid page type page=abc | PASS |
| C047 | Invalid page type page=2147483648 | PASS |
| C048 | Trim names and support Unicode | PASS |
| C049 | Unicode names are preserved | PASS |
| C050 | Pagination setup 0 | PASS |
| C051 | Pagination setup 1 | PASS |
| C052 | Pagination setup 2 | PASS |
| C053 | Pagination setup 3 | PASS |
| C054 | Pagination setup 4 | PASS |
| C055 | Pagination setup 5 | PASS |
| C056 | Pagination setup 6 | PASS |
| C057 | Pagination setup 7 | PASS |
| C058 | Pagination setup 8 | PASS |
| C059 | Pagination setup 9 | PASS |
| C060 | Pagination setup 10 | PASS |
| C061 | Pagination setup 11 | PASS |
| C062 | Middle page | PASS |
| C063 | Page clamps after final page | PASS |
| C064 | No search results | PASS |
| C065 | List in insertion order | PASS |
| C066 | Delete first record | PASS |
| C067 | Delete middle record | PASS |
| C068 | Delete last record | PASS |
| C069 | Remaining records keep valid IDs | PASS |
| C070 | Lookup remaining student 1002 | PASS |
| C071 | Lookup remaining student 1003 | PASS |
| C072 | Lookup remaining student 1004 | PASS |
| C073 | Lookup remaining student 1005 | PASS |
| C074 | Lookup remaining student 1006 | PASS |
| C075 | Lookup remaining student 1007 | PASS |
| C076 | Lookup remaining student 1008 | PASS |
| C077 | Lookup remaining student 1010 | PASS |
| C078 | Lookup remaining student 1011 | PASS |
| C079 | Lookup remaining student 1012 | PASS |
| C080 | Lookup remaining student 1013 | PASS |
| C081 | Lookup remaining student 1014 | PASS |
| C082 | Lookup remaining student 1015 | PASS |
| C083 | Lookup remaining student 1016 | PASS |
| C084 | ID not reused after deletions | PASS |
| C085 | Shared asset StudentsLogin.html | PASS |
| C086 | Shared asset StudentsManagement.html | PASS |
| C087 | Shared asset enrollment.js | PASS |
| C088 | Shared asset enrollment.css | PASS |
| C089 | Staff logout | PASS |
| C090 | Signed-out client denied | PASS |
| C091 | Sign in again | PASS |
| C092 | Records survive logout within this run | PASS |
| C093 | Restart requires login | PASS |
| C094 | Login after restart | PASS |
| C095 | Restart clears data | PASS |
| C096 | New run restarts ID counter | PASS |

JSON is compared structurally, with exact message strings. Shared browser files are compared byte for byte. Cookie contents and HTTP transport headers are excluded. External mode leaves server restarts to the implementation owner.
