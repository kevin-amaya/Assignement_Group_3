"""AI-assisted, implementation-independent enrollment contract checks.

This file is a TEST TOOL, not the Part 3 enrollment implementation.
C# mode: build/start an isolated C# server and verify its public contract.
External mode: verify Kevin's fresh local server; no .NET SDK is needed.
It never sends messages, writes GitHub, uploads files or submits the assignment.
"""
import argparse
from datetime import timedelta, datetime, timezone
import hashlib
from http.cookiejar import CookieJar
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import traceback
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import build_opener, HTTPCookieProcessor, Request

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "tools" / "_artifacts"


class Client:
    def __init__(self, base_url):
        self.base = base_url.rstrip("/")
        self.opener = build_opener(HTTPCookieProcessor(CookieJar()))

    def request(self, method, path, data=None, raw=None):
        payload = raw if raw is not None else json.dumps(data).encode() if data is not None else None
        request = Request(self.base + path, data=payload, method=method,
                          headers={"Content-Type":"application/json"} if payload is not None else {})
        try:
            response = self.opener.open(request, timeout=10)
        except HTTPError as error:
            response = error
        with response:
            return response.code, json.loads(response.read())

    def asset(self, path):
        with self.opener.open(self.base + path, timeout=10) as response:
            return response.code, response.read()


class CSharpServer:
    def __init__(self, dotnet):
        self.dotnet = dotnet
        self.process = None
        self.log = None

    def start(self):
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        self.log = (ARTIFACTS / "csharp-server.log").open("ab")
        command = [self.dotnet, str(ROOT / "bin/Debug/net10.0/VariablesTypesStatementsSubprograms.dll"),
                   "--urls", f"http://127.0.0.1:{port}"]
        environment = dict(os.environ, DOTNET_CLI_TELEMETRY_OPTOUT="1", DOTNET_NOLOGO="1")
        self.process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=self.log,
            stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        client = Client(f"http://127.0.0.1:{port}")
        deadline = time.monotonic() + 30
        while True:
            if self.process.poll() is not None:
                raise RuntimeError("C# exited; see tools/_artifacts/csharp-server.log.")
            try:
                if client.asset("/StudentsLogin.html")[0] == 200:
                    return client
            except (OSError, URLError):
                pass
            if time.monotonic() > deadline:
                raise TimeoutError("C# did not become ready.")
            time.sleep(0.1)

    def stop(self):
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        if self.log is not None:
            self.log.close()
        self.process = None
        self.log = None


class Verifier:
    def __init__(self, client, reference=None):
        self.client = client
        self.cases = []
        self.reference = {row["id"]:row for row in (reference or {}).get("cases", [])}

    def _compare_reference(self, row):
        expected = self.reference.get(row["id"])
        if expected is None:
            if self.reference:
                raise AssertionError(f"Reference case {row['id']} is missing.")
            return
        fields = ("status", "response") if row["kind"] == "api" else ("status", "sha256", "bytes")
        for field in fields:
            assert row[field] == expected[field], (
                f"Reference mismatch in {row['id']} {field}: "
                f"actual={row[field]!r}, expected={expected[field]!r}")

    def check(self, label, method, path, data=None, status=200, success=True,
              value=None, predicate=None, raw=None):
        code, body = self.client.request(method, path, data, raw)
        row = dict(id=f"C{len(self.cases)+1:03}", kind="api", name=label,
                   method=method, path=path, request=data, status=code, response=body,
                   passed=False)
        if raw is not None:
            row["raw_request"] = raw.decode("utf-8", errors="replace")
        self.cases.append(row)
        assert code == status, (label, code, status, body)
        assert body["Key"] is success, (label, body)
        if value is not None:
            assert body["Value"] == value, (label, body)
        if predicate:
            assert predicate(body["Value"]), (label, body)
        self._compare_reference(row)
        row["passed"] = True
        return body["Value"]

    def check_asset(self, name):
        code, content = self.client.asset("/"+name)
        row = dict(id=f"C{len(self.cases)+1:03}", kind="asset", name=f"Shared asset {name}",
                   method="GET", path="/"+name, status=code,
                   bytes=len(content), sha256=hashlib.sha256(content).hexdigest(), passed=False)
        self.cases.append(row)
        assert code == 200, name
        assert content == (ROOT / "wwwroot" / name).read_bytes(), f"Changed browser asset: {name}"
        self._compare_reference(row)
        row["passed"] = True


def sample(**changes):
    student = dict(firstName="Ada", lastName="Lovelace", birthDay="2000-02-29",
                   gender="Woman", program="Software Development", currentSemester=1,
                   numberOfCourses=5, previousGPA=3.7)
    student.update(changes)
    return student


def main():
    parser = argparse.ArgumentParser(description="Check a fresh enrollment server using fictional records.")
    parser.add_argument("--dotnet", default=shutil.which("dotnet"))
    parser.add_argument("--base-url", help="A fresh dedicated local server; skip C# build/start.")
    parser.add_argument("--reference", type=Path, help="Recorded C# JSON to compare each result with.")
    parser.add_argument("--output", type=Path, default=ARTIFACTS/"contract_results.json")
    args = parser.parse_args()
    if args.base_url:
        address = urlsplit(args.base_url)
        if (address.scheme != "http" or address.hostname not in ("localhost","127.0.0.1","::1")
                or address.path not in ("","/") or address.query or address.fragment):
            parser.error("--base-url must identify a local HTTP test server without a path or query.")
    elif not args.dotnet:
        parser.error("Use a .NET 10 SDK through --dotnet, or test an existing server with --base-url.")
    reference = json.loads(args.reference.read_text(encoding="utf-8-sig")) if args.reference else None
    if reference is not None and not reference.get("passed"):
        parser.error("--reference must be a passing C# result file.")
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    if not args.base_url:
        environment = dict(os.environ, DOTNET_CLI_TELEMETRY_OPTOUT="1", DOTNET_NOLOGO="1")
        build = subprocess.run([args.dotnet,"build","--nologo"], cwd=ROOT, env=environment,
                               capture_output=True, text=True, encoding="utf-8", errors="replace")
        (ARTIFACTS/"build.log").write_text(build.stdout+build.stderr, encoding="utf-8")
        if build.returncode:
            print(build.stdout, build.stderr)
            return 1
    manager = CSharpServer(args.dotnet) if not args.base_url else None
    verifier = Verifier(Client(args.base_url) if args.base_url else None, reference)
    failure = None
    skipped = []
    started = datetime.now(timezone.utc).isoformat()
    try:
        if manager is not None:
            verifier.client = manager.start()
        check = verifier.check
        check("Unauthorized enrollment access", "GET", "/api/Students", status=401,
              success=False, value="Please sign in.")
        check("Wrong password", "POST", "/api/Login", {"username":"admin","password":"wrong"},
              status=401, success=False, value="Invalid username or password.")
        check("Staff login", "POST", "/api/Login", {"username":"admin","password":"admin"},
              value="Login successful.")
        check("Empty collection", "GET", "/api/Students",
              value=dict(totalNumber=0, totalPages=0, pageNumber=1, pageSize=10, students=[]))
        check("Add required fields", "POST", "/api/Students", sample(), value="Added Student ID: 1001")
        check("Retrieve all student fields", "GET", "/api/Students/1001",
              value=dict(id=1001, name="Ada Lovelace", **sample()))
        check("Same identifying fields get another ID", "POST", "/api/Students", sample(),
              value="Added Student ID: 1002")
        updated = sample(firstName="Augusta", program="Cybersecurity", currentSemester=2, previousGPA=3.92)
        check("Edit program and name by stable ID", "PUT", "/api/Students/1001", updated, value="Record updated.")
        check("Edited record retains ID", "GET", "/api/Students/1001",
              value=dict(id=1001, name="Augusta Lovelace", **updated))
        check("Other student is unchanged", "GET", "/api/Students/1002",
              value=dict(id=1002, name="Ada Lovelace", **sample()))
        check("Reject invalid edit", "PUT", "/api/Students/1001", sample(previousGPA=4.1),
              status=400, success=False, value="GPA must be a number between 0.0 and 4.0.")
        check("Rejected edit leaves the whole record unchanged", "GET", "/api/Students/1001",
              value=dict(id=1001, name="Augusta Lovelace", **updated))
        for method in ("GET", "PUT", "DELETE"):
            check(f"Unknown ID {method}", method, "/api/Students/999999",
                  sample() if method == "PUT" else None, status=404,
                  success=False, value="Student not found.")
        check("Malformed JSON", "POST", "/api/Students", raw=b"{", status=400,
              success=False, value="Invalid request data.")
        for field, bad in (("currentSemester","2"),("numberOfCourses",2.5),
                           ("numberOfCourses",True),("previousGPA","3.5"),
                           ("numberOfCourses",2**31),("firstName",123)):
            check(f"Wrong JSON type or range {field} {bad!r}", "POST", "/api/Students", sample(**{field:bad}),
                  status=400, success=False, value="Invalid request data.")
        for field, label in (("firstName","First name"),("lastName","Last name"),
                             ("gender","Gender"),("program","Program")):
            for bad in ("   ", "x"*101):
                check(f"Required text validation {field} length {len(bad)}", "POST", "/api/Students",
                      sample(**{field:bad}), status=400, success=False,
                      value=f"{label} must contain 1 to 100 characters.")
        tomorrow = (datetime.now(timezone.utc).date()+timedelta(days=1)).isoformat()
        for birthday in ("2025-02-29","2000-02-30","01/02/2000",tomorrow):
            check(f"Invalid date {birthday}", "POST", "/api/Students", sample(birthDay=birthday),
                  status=400, success=False,
                  value="Date of birth must be a valid date in YYYY-MM-DD format and cannot be in the future.")
        for gpa in (0.0, 4.0):
            check(f"Valid GPA boundary {gpa}", "POST", "/api/Students", sample(previousGPA=gpa))
        for gpa in (-0.001, 4.001, None):
            check(f"Invalid GPA {gpa}", "POST", "/api/Students", sample(previousGPA=gpa),
                  status=400, success=False, value="GPA must be a number between 0.0 and 4.0.")
        check("Negative course count", "POST", "/api/Students", sample(numberOfCourses=-1),
              status=400, success=False, value="Number of courses must be a whole number of 0 or greater.")
        check("Zero semester", "POST", "/api/Students", sample(currentSemester=0),
              status=400, success=False, value="Semester must be a whole number of 1 or greater.")
        for query in ("page=0","page=-1","pageSize=0","pageSize=101"):
            check(f"Pagination validation {query}", "GET", "/api/Students?"+query, status=400,
                  success=False, value="Page must be 1 or greater and page size must be between 1 and 100.")
        for query in ("page=abc","page=2147483648"):
            check(f"Invalid page type {query}", "GET", "/api/Students?"+query, status=400,
                  success=False, value="Invalid request data.")
        check("Trim names and support Unicode", "POST", "/api/Students",
              sample(firstName="  Chloé  ",lastName="李",numberOfCourses=0,program="Systems & <Research>"))
        check("Unicode names are preserved", "GET", "/api/Students/1005",
              predicate=lambda student: student["firstName"] == "Chloé" and student["lastName"] == "李")
        for index in range(12):
            check(f"Pagination setup {index}", "POST", "/api/Students", sample(firstName="Series",lastName=str(index)))
        check("Middle page", "GET", "/api/Students?name=Series&page=2&pageSize=5",
              predicate=lambda result: result["totalNumber"]==12 and result["totalPages"]==3
              and [s["lastName"] for s in result["students"]]==[str(i) for i in range(5,10)])
        check("Page clamps after final page", "GET", "/api/Students?name=Series&page=999&pageSize=5",
              predicate=lambda result: result["pageNumber"]==3 and len(result["students"])==2)
        check("No search results", "GET", "/api/Students?name=NoMatchingStudent",
              predicate=lambda result: result["totalNumber"]==0 and result["students"]==[])
        before = check("List in insertion order", "GET", "/api/Students?pageSize=100")
        identifiers = [student["id"] for student in before["students"]]
        for label, student_id in zip(("first","middle","last"),
                                    (identifiers[0], identifiers[len(identifiers)//2], identifiers[-1])):
            check(f"Delete {label} record", "DELETE", f"/api/Students/{student_id}", value="Record removed.")
        after = check("Remaining records keep valid IDs", "GET", "/api/Students?pageSize=100",
                      predicate=lambda result: result["totalNumber"]==before["totalNumber"]-3)
        for student in after["students"]:
            check(f"Lookup remaining student {student['id']}", "GET", f"/api/Students/{student['id']}", value=student)
        check("ID not reused after deletions", "POST", "/api/Students", sample(),
              value=f"Added Student ID: {max(identifiers)+1}")
        for asset in ("StudentsLogin.html","StudentsManagement.html","enrollment.js","enrollment.css"):
            verifier.check_asset(asset)
        check("Staff logout", "POST", "/api/Login/logout", value="Logout successful.")
        check("Signed-out client denied", "GET", "/api/Students", status=401, success=False, value="Please sign in.")
        check("Sign in again", "POST", "/api/Login", {"username":"admin","password":"admin"})
        check("Records survive logout within this run", "GET", "/api/Students",
              predicate=lambda result: result["totalNumber"]==len(identifiers)-2)
        if manager is not None:
            signed_in_client = verifier.client
            manager.stop()
            restarted_client = manager.start()
            # Retain the pre-restart session cookie while changing to the new port.
            # This checks that a previously authenticated session is invalidated.
            signed_in_client.base = restarted_client.base
            verifier.client = signed_in_client
            check("Restart requires login", "GET", "/api/Students", status=401,
                  success=False,value="Please sign in.")
            check("Login after restart", "POST", "/api/Login", {"username":"admin","password":"admin"})
            check("Restart clears data", "GET", "/api/Students",
                  predicate=lambda result: result["totalNumber"]==0)
            check("New run restarts ID counter", "POST", "/api/Students", sample(), value="Added Student ID: 1001")
        else:
            skipped = ["Restart requires login", "Login after restart",
                       "Restart clears data", "New run restarts ID counter"]
    except Exception:
        failure = traceback.format_exc()
        print(failure)
    finally:
        if manager is not None:
            manager.stop()
        report = dict(schema_version=1, started_utc=started,
                      finished_utc=datetime.now(timezone.utc).isoformat(),
                      implementation="external server" if args.base_url else "C#",
                      passed=failure is None, checks=len(verifier.cases),
                      restart_checks="not run in external mode" if args.base_url else "performed",
                      skipped_cases=skipped, failure=failure, cases=verifier.cases)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
        lines = ["# Enrollment contract test results", "",
                 f"Overall: {'PASS' if report['passed'] else 'FAIL'}",
                 f"Checks: {report['checks']}",
                 f"Restart checks: {report['restart_checks']}", "",
                 "| ID | Case | Result |", "| --- | --- | --- |"]
        lines += [f"| {row['id']} | {row['name']} | {'PASS' if row['passed'] else 'FAIL'} |"
                  for row in verifier.cases]
        lines += ["", "JSON is compared structurally, with exact message strings. Shared browser files are compared byte for byte. Cookie contents and HTTP transport headers are excluded. External mode leaves server restarts to the implementation owner."]
        args.output.with_suffix(".md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(f"{'PASS' if failure is None else 'FAIL'}: {len(verifier.cases)} contract checks")
    if skipped:
        print("Not run in external mode: four restart checks. Restart the server and verify reset separately.")
    return 0 if failure is None else 1


if __name__ == "__main__":
    raise SystemExit(main())
