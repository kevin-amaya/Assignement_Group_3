// Origin: Hua's list/dictionary repository, substantially revised with ChatGPT/Codex.
// AI-assisted changes: stable IDs, validated atomic edits, snapshots and locking.
using EnrollmentSystem.DTOs;
using EnrollmentSystem.Models;
namespace EnrollmentSystem.Repositories;

/// <summary>Application-lifetime in-memory storage, with no persistence.</summary>
public class StudentsRepo
{
    private readonly List<StudentsDTO> studentList = new();
    private readonly Dictionary<int, StudentsDTO> studentsById = new();
    private readonly object syncRoot = new();
    private int nextId = 1001;

    // ref changes the caller's counter; ordinary studentId parameters pass by value.
    private static int AllocateId(ref int counter)
    {
        int assignedId = counter;
        counter = checked(counter + 1);
        return assignedId;
    }

    public StudentsModel InsertStudent(StudentsDTO validated)
    {
        lock (syncRoot)
        {
            validated.id = AllocateId(ref nextId);
            studentList.Add(validated);
            studentsById.Add(validated.id, validated);
            return new StudentsModel(validated);
        }
    }

    public bool UpdateStudent(int studentId, StudentsDTO validated)
    {
        lock (syncRoot)
        {
            if (!studentsById.TryGetValue(studentId, out StudentsDTO? storedStudent))
                return false;
            // Both containers reference this object. Its stable ID is never edited.
            storedStudent.firstName = validated.firstName;
            storedStudent.lastName = validated.lastName;
            storedStudent.birthDay = validated.birthDay;
            storedStudent.gender = validated.gender;
            storedStudent.program = validated.program;
            storedStudent.currentSemester = validated.currentSemester;
            storedStudent.numberOfCourses = validated.numberOfCourses;
            storedStudent.previousGPA = validated.previousGPA;
            return true;
        }
    }

    public StudentsModel? GetStudent(int studentId)
    {
        lock (syncRoot)
            return studentsById.TryGetValue(studentId, out StudentsDTO? student)
                ? new StudentsModel(student) : null;
    }

    public bool DeleteStudent(int studentId)
    {
        lock (syncRoot)
        {
            if (!studentsById.Remove(studentId, out StudentsDTO? student))
                return false;
            studentList.Remove(student);
            return true;
        }
    }

    public QueryResultModel GetStudents(StudentsQueryModel query)
    {
        lock (syncRoot)
        {
            // Case-sensitive search and insertion order are shared with Python.
            var matching = studentList.Where(student =>
                student.name.Contains(query.name ?? "", StringComparison.Ordinal)).ToList();
            int total = matching.Count;
            int pages = (int)Math.Ceiling((double)total / query.pageSize);
            int effectivePage = pages == 0 ? 1 : Math.Min(query.page, pages);
            return new QueryResultModel
            {
                totalNumber = total, totalPages = pages,
                pageNumber = effectivePage, pageSize = query.pageSize,
                students = matching.Skip((effectivePage - 1) * query.pageSize)
                    .Take(query.pageSize).Select(student => new StudentsModel(student)).ToList()
            };
        }
    }
}
