// Origin: Hua's demo credential repository, AI-assisted revision.
namespace EnrollmentSystem.Repositories;
public class LoginRepo
{
    // Classroom prototype credentials: supported accounts are administrative staff.
    private static readonly Dictionary<string, string> userCredentials = new()
    {
        { "admin", "admin" }
    };
    public Dictionary<string, string> getUserCredentials() => userCredentials;
}
