namespace EnrollmentSystem.Models
{
    public class StudentsQueryModel: StudentsModel
    {
        public string studentHash { get; set; } = string.Empty;

        public int page { get; set; } = 1;
        public int pageSize { get; set; } = 10;
    }
}