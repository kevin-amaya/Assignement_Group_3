
using EnrollmentSystem.DTOs;

namespace EnrollmentSystem.Models
{
    public class StudentsModel
    {
        public StudentsModel()
        {
        }

        public string id { get; set; } = string.Empty;
        public string name { get; set; } = string.Empty;
        public string birthDay { get; set; } = string.Empty;
        public string gender { get; set; } = string.Empty;
        public string program { get; set; } = string.Empty;
        public int currentSemester { get; set; } = 0;
        public int numberOfCourses { get; set; } = 0;
        public double previousGPA { get; set; } = 0.0;

        public StudentsModel(StudentsDTO studentsDTO)
        {
            this.id = studentsDTO.id;
            this.name = studentsDTO.name;
            this.birthDay = studentsDTO.birthDay;
            this.gender = studentsDTO.gender;
            this.program = studentsDTO.program;
            this.currentSemester = studentsDTO.currentSemester;
            this.numberOfCourses = studentsDTO.numberOfCourses;
            this.previousGPA = studentsDTO.previousGPA;
        }

        public static List<StudentsModel> cloneDTOToModel(List<StudentsDTO> studentsDTOList)
        {
            return studentsDTOList.Select(s => new StudentsModel(s)).ToList();
        }
    }
}
