namespace EnrollmentSystem.Repositories
{
    public class LoginRepo
    {
        private static Dictionary<string, string> userCredentials = new Dictionary<string, string>
        {
            { "admin", "admin" },
            { "user1", "password1" },
            { "user2", "password2" }
        };
        public Dictionary<string, string> getUserCredentials() 
        {
            return userCredentials;
        }
    }
}