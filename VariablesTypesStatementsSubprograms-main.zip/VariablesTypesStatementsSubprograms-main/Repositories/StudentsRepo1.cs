using EnrollmentSystem.DTOs;
using EnrollmentSystem.Models;


namespace EnrollmentSystem.Repositories
{
    /**
        * StudentsRepo is a repository class that manages student information.
        * It provides methods(insertOrUpdateStudent, getStudentByHash, delStudentByHash, and getStudentsByQuery) 
        * to insert, update, delete, and retrieve student information.
        * It uses a dictionary to store student hash and id, and a list to store student basic information.
        */
    public class StudentsRepo1
    {
        // Store student's hash(name + birthDay + gender + program) and id.
        Dictionary<string, int> studentHashAndId = new Dictionary<string, int>();
        // Store student's basic information: name, birthDay, gender, program, currentSemester, numberOfCourses, previousGPA.
        List<StudentsDTO> studentList = new List<StudentsDTO>();
        // Get student's id by student's basic information, if not exist, return a new id.
        private int getStudentId(StudentsModel studentsModel)
        {
            if(studentHashAndId.ContainsKey(getStudentHash(studentsModel)))
            {
                return studentHashAndId[getStudentHash(studentsModel)];
            } else
            {
                return studentHashAndId.Count + 1;
            }
        }
        // get student's hash(name + birthDay + gender + program) by student's basic information.
        private string getStudentHash(StudentsModel studentsModel)
        {
            string studentHash = studentsModel.name + studentsModel.birthDay + studentsModel.gender + studentsModel.program;
            return studentHash;
        }

        // insert or update student information and return true if successful, false otherwise
        public KeyValuePair<bool, string> insertOrUpdateStudent(StudentsModel studentsModel)
        {
            string studentHash = getStudentHash(studentsModel);
            int studentId = getStudentId(studentsModel);

            if (studentHashAndId.ContainsKey(studentHash))
            {
                var studentBasicInfo = studentList[studentId];
                studentBasicInfo.name = studentsModel.name;
                studentBasicInfo.birthDay = studentsModel.birthDay;
                studentBasicInfo.gender = studentsModel.gender;
                studentBasicInfo.program = studentsModel.program;
                studentBasicInfo.currentSemester = studentsModel.currentSemester;
                studentBasicInfo.numberOfCourses = studentsModel.numberOfCourses;
                studentBasicInfo.previousGPA = studentsModel.previousGPA;
                return new KeyValuePair<bool, string>(true, "Student updated successfully");
            } else
            {
                studentHashAndId[studentHash] = studentId;
                var studentBasicInfo = new StudentsDTO
                {
                    name = studentsModel.name,
                    birthDay = studentsModel.birthDay,
                    gender = studentsModel.gender,
                    program = studentsModel.program,
                    currentSemester = studentsModel.currentSemester,
                    numberOfCourses = studentsModel.numberOfCourses,
                    previousGPA = studentsModel.previousGPA
                };
                studentList[studentId] = studentBasicInfo;
                return new KeyValuePair<bool, string>(true, "Student inserted successfully");
            }
            
        }

        // get student's basic information by studentHash, return StudentDTO,
        //  if not exist, throw an exception
        public StudentsDTO getStudentByHash(string studentHash)
        {
            if (studentHashAndId.ContainsKey(studentHash))
            {
                int studentId = studentHashAndId[studentHash];
                return studentList[studentId];
            }
            else
            {
                throw new Exception("Student not found");
            }
        }
        // delete student by studentHash, return true if successful, false otherwise.
         public KeyValuePair<bool, string> delStudentByHash(string studentHash)
        {
            if (studentHashAndId.ContainsKey(studentHash))
            {
                int studentId = studentHashAndId[studentHash];
                studentList.RemoveAt(studentId);
                studentHashAndId.Remove(studentHash);
                return new KeyValuePair<bool, string>(true, "Student deleted successfully");
            }
            else
            {
                return new KeyValuePair<bool, string>(false, "Student not found");
            }
        }
        // get students by query, return a list of StudentDTO, 
        // if name is null, return all students, otherwise return students whose name contains the query string.
        public List<StudentsDTO> getStudentsByQuery(StudentsModel studentsModel, int page, int pageSize)
        {
            if(studentsModel.name is null)
            {
                return studentList.Skip((page - 1) * pageSize).Take(pageSize).ToList();
            }
            else
            {
                return studentList.Where(s => s.name.Contains(studentsModel.name)).Skip((page - 1) * pageSize).Take(pageSize).ToList();
            } 
        }
        // get total number of students by query, return the total number of students whose name contains the query string.
        public int getTotalStudentsByQuery(StudentsModel studentsModel)
        {
            if(studentsModel.name is null)
            {
                return studentList.Count;
            }
            else
            {
                return studentList.Where(s => s.name.Contains(studentsModel.name)).Count();
            } 
        }
    }

}