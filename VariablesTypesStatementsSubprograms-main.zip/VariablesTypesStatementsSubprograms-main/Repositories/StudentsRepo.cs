using System.Security.Cryptography;
using System.Text;
using EnrollmentSystem.DTOs;
using EnrollmentSystem.Models;

namespace EnrollmentSystem.Repositories
{
    /**
        * StudentsRepo is a repository class that manages student information.
        * It provides methods(insertOrUpdateStudent, getStudentByHash, delStudentByHash, and getStudentsByQuery) 
        * to insert, update, delete, and retrieve student information.
        * It uses a dictionary to store student hash and id, and a list to store student basic information.
        */
    public class StudentsRepo
    {
        // Store student's hash(name + birthDay + gender + program) and id.
        Dictionary<string, int> studentHashAndId = new Dictionary<string, int>();
        // Store student's basic information: name, birthDay, gender, program, currentSemester, numberOfCourses, previousGPA.
        List<StudentsDTO> studentList = new List<StudentsDTO>();
        // Get student's id by student's basic information, if not exist, return a new id.
        private int getStudentId(StudentsQueryModel studentsQueryModel)
        {
            if(studentHashAndId.ContainsKey(getStudentHash(studentsQueryModel)))
            {
                return studentHashAndId[getStudentHash(studentsQueryModel)];
            } else
            {
                return studentHashAndId.Count;
            }
        }

        // get student's hash(name + birthDay + gender + program) by student's basic information.
        private string getStudentHash(StudentsQueryModel studentsQueryModel)
        {
            string studentHash = studentsQueryModel.name + studentsQueryModel.birthDay + studentsQueryModel.gender + studentsQueryModel.program;
            byte[] inputBytes = Encoding.UTF8.GetBytes(studentHash);
            byte[] md5Bytes = MD5.HashData(inputBytes);
            string md5Hex = Convert.ToHexString(md5Bytes);
            return md5Hex;
        }

        public string getStudentHash(string studentHash)
        {
            byte[] inputBytes = Encoding.UTF8.GetBytes(studentHash);
            byte[] md5Bytes = MD5.HashData(inputBytes);
            string md5Hex = Convert.ToHexString(md5Bytes);
            return md5Hex;
        }

        // insert or update student information and return true if successful, false otherwise
        public KeyValuePair<bool, string> insertOrUpdateStudent(StudentsQueryModel studentsQueryModel)
        {
            string studentHash = getStudentHash(studentsQueryModel);
            int studentId = getStudentId(studentsQueryModel);
            Console.WriteLine($"studentHash: {studentHash}, studentId: {studentId}");
            if (studentHashAndId.ContainsKey(studentHash))
            {
                var studentBasicInfo = studentList[studentId];
                studentBasicInfo.name = studentsQueryModel.name;
                studentBasicInfo.birthDay = studentsQueryModel.birthDay;
                studentBasicInfo.gender = studentsQueryModel.gender;
                studentBasicInfo.program = studentsQueryModel.program;
                studentBasicInfo.currentSemester = studentsQueryModel.currentSemester;
                studentBasicInfo.numberOfCourses = studentsQueryModel.numberOfCourses;
                studentBasicInfo.previousGPA = studentsQueryModel.previousGPA;
                return new KeyValuePair<bool, string>(true, "Student updated successfully");
            } else
            {
                studentHashAndId[studentHash] = studentId;
                var studentBasicInfo = new StudentsDTO
                {
                    id = studentHash,
                    name = studentsQueryModel.name,
                    birthDay = studentsQueryModel.birthDay,
                    gender = studentsQueryModel.gender,
                    program = studentsQueryModel.program,
                    currentSemester = studentsQueryModel.currentSemester,
                    numberOfCourses = studentsQueryModel.numberOfCourses,
                    previousGPA = studentsQueryModel.previousGPA
                };
                studentList.Add(studentBasicInfo);
                Console.WriteLine($"student name: {studentList[studentId].name}, studentList size: {studentList.Count}");
                return new KeyValuePair<bool, string>(true, "Student inserted successfully");
            }
            
        }

        // get student's basic information by studentHash, return StudentDTO,
        //  if not exist, throw an exception
        public StudentsDTO getStudentByHash(string studentHash)
        {
            if (studentHashAndId.ContainsKey(studentHash))
            {
                int studentId = studentHashAndId[studentHash];
                return studentList[studentId];
            }
            else
            {
                throw new Exception("Student not found");
            }
        }
        // delete student by studentHash, return true if successful, false otherwise.
         public KeyValuePair<bool, string> delStudentByHash(string studentHash)
        {
            if (studentHashAndId.ContainsKey(studentHash))
            {
                int studentId = studentHashAndId[studentHash];
                studentList.RemoveAt(studentId);
                studentHashAndId.Remove(studentHash);
                // sacrificing performance for simplicity, we will update the indices of the students in the list after deletion
                // this is because we are using a list to store students. The data structure is good for pagination, but not good for deletion. 
                // update the studentHashAndId dictionary to reflect the new indices of the students in the list
                for (int i = studentId; i < studentList.Count; i++)
                {
                    string studentHashToUpdate = studentList[i].id;
                    studentHashAndId[studentHashToUpdate] = i;
                }
                return new KeyValuePair<bool, string>(true, "Student deleted successfully");
            }
            else
            {
                return new KeyValuePair<bool, string>(false, "Student not found");
            }
        }
        // get students by query, return a list of StudentDTO, 
        // if name is null, return all students, otherwise return students whose name contains the query string.
        public List<StudentsDTO> getStudentsByQuery(StudentsQueryModel studentsQueryModel)
        {
            if(studentsQueryModel.name is null)
            {
                return studentList.Skip((studentsQueryModel.page - 1) * studentsQueryModel.pageSize).Take(studentsQueryModel.pageSize).ToList();
            }
            else
            {
                return studentList.Where(s => s.name.Contains(studentsQueryModel.name)).Skip((studentsQueryModel.page - 1) * studentsQueryModel.pageSize).Take(studentsQueryModel.pageSize).ToList();
            } 
        }
        // get total number of students by query, return the total number of students whose name contains the query string.
        public int getTotalStudentsByQuery(StudentsQueryModel studentsQueryModel)
        {
            if(studentsQueryModel.name is null)
            {
                return studentList.Count;
            }
            else
            {
                return studentList.Where(s => s.name.Contains(studentsQueryModel.name)).Count();
            } 
        }
    }

}