```Instructions
You have been tasked with developing a prototype enrollment management system for SAIT. This system will handle the enrollment of students and manage their information efficiently.

Each student must have the following information:

First name and last name
Date of birth
Gender
GPA from a previous institution
Current semester
Program
Number of courses
The enrollment system will be managed by the institution’s administrative staff, and students will not have access to enroll themselves.

Your program should be designed to use various data structures such as arrays, lists, tuples or any other suitable data structure. While data persistence is not required at this stage, 
the system should allow users to modify or remove student records, as well as add new student records during a single run of the program.
```

```Part 2: Using a Programming Language
Develop a program in C, C++, C#, or Java based on the pseudocode algorithm created in Part 1. Your program should implement the steps outlined in the pseudocode to manage student enrollment effectively.
Ensure that your program emphasizes the following concepts:
Proper choice of variable names: Use meaningful and descriptive names for variables to enhance code readability and maintainability.
Data binding (static and dynamic): Demonstrate the use of static and dynamic data binding techniques as appropriate for managing student data.
Scoping: Implement proper variable scoping to control the visibility and accessibility of variables within different parts of your program.
Referencing: Use appropriate referencing mechanisms to access and manipulate data stored in different containers (e.g., arrays, lists).
Use of a wide range of data types: Employ various data types, including arrays, strings, and primitive data types, to represent different attributes of student records.
Conditional statements and branching: Incorporate conditional statements (e.g., if-else statements, switch cases) and branching logic to implement decision-making processes within your program.
Subprograms: Implement subprograms or functions to encapsulate specific tasks or operations within your program, such as adding, modifying or removing student records. Ensure proper usage of pass by reference and pass by value when passing arguments to subprograms.
Integrate the logic and structure outlined in your pseudocode algorithm from Part 1 into your program. Refer to your pseudocode to guide the implementation process and ensure consistency between the algorithm and the actual code.
Document your code thoroughly, including comments and annotations, to explain the purpose of each section and facilitate understanding for others who may review or modify your code.
Test your program against various scenarios and edge cases to verify its functionality, correctness and robustness in managing student enrollment operations.
```
