using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using EnrollmentSystem.Services;

namespace EnrollmentSystem.Controller
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController: ControllerBase
    {
        private readonly LoginService _loginService;

        public LoginController(LoginService loginService)
        {
            _loginService = loginService;
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<KeyValuePair<bool, string>> login(string username, string password)
        {
            var result = await _loginService.login(username, password);
            if (!result.Key)
            {
                // If login fails, return a 401 Unauthorized response
                throw new UnauthorizedAccessException(result.Value);
            }
            return result;
        }
    }
}