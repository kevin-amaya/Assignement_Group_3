using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using EnrollmentSystem.Models;
using EnrollmentSystem.Services;

namespace EnrollmentSystem.Controller
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StudentsController: ControllerBase
    {
        private readonly StudentService _studentService;

        public StudentsController(StudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpPost]
        public KeyValuePair<bool, string> insertStudent([FromBody] StudentsQueryModel studentsQueryModel)
        {
            return _studentService.insertStudent(studentsQueryModel);
        }

        [HttpPut("{studentHash}")]
        public KeyValuePair<bool, string> updateStudent([FromBody] StudentsQueryModel studentsQueryModel)
        {
            return _studentService.updateStudentByHash(studentsQueryModel);
        }

        [HttpGet("{studentHash}")]
        public KeyValuePair<bool, StudentsModel> getStudentByHash([FromRoute] string studentHash)
        {
            return _studentService.getStudentByHash(studentHash);
        }

        [HttpDelete("{studentHash}")]
        public KeyValuePair<bool, string> delStudentByHash([FromRoute] string studentHash)
        {
            return _studentService.delStudentByHash(studentHash);
        }

        [HttpGet]
        public KeyValuePair<bool, QueryResultModel> getStudentsByQuery([FromQuery] StudentsQueryModel studentsQueryModel)
        {
            return _studentService.getStudentsByQuery(studentsQueryModel);
        }
    }
}