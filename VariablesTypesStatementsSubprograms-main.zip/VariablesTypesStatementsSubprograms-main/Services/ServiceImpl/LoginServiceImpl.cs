using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using EnrollmentSystem.Repositories;

namespace EnrollmentSystem.Services.Impl
{
    public class LoginServiceImpl : LoginService
    {
        private readonly LoginRepo loginRepo;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public LoginServiceImpl(LoginRepo loginRepo, IHttpContextAccessor httpContextAccessor)
        {
            this.loginRepo = loginRepo;
            this._httpContextAccessor = httpContextAccessor;
        }

        public async Task<KeyValuePair<bool, string>> login(string username, string password)
        {
            bool isValidUser = loginRepo.getUserCredentials().TryGetValue(username, out string storedPassword) && storedPassword == password;
            if (isValidUser)
            {
                Guid uuid = Guid.NewGuid();
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, username),
                    new Claim(ClaimTypes.NameIdentifier, username),
                    new Claim(ClaimTypes.Role, "Admin")
                };
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);

                await _httpContextAccessor.HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme, 
                    claimsPrincipal
                );
                return new KeyValuePair<bool, string>(true, "Login successful");
            }
            else
            {
                return new KeyValuePair<bool, string>(false, "Invalid username or password");
            }
        }
    }
}