using EnrollmentSystem.Models;
using EnrollmentSystem.Repositories;

namespace EnrollmentSystem.Services.Impl
{
    public class StudentServiceImpl : StudentService
    {
        private readonly StudentsRepo studentsRepo;

        public StudentServiceImpl(StudentsRepo studentsRepo)
        {
            this.studentsRepo = studentsRepo;
        }

        public KeyValuePair<bool, string> insertStudent(StudentsQueryModel studentsQueryModel)
        {
            return studentsRepo.insertOrUpdateStudent(studentsQueryModel);
        }

        public KeyValuePair<bool, string> updateStudentByHash(StudentsQueryModel studentsQueryModel)
        {
            return studentsRepo.insertOrUpdateStudent(studentsQueryModel);
        }

        public KeyValuePair<bool, StudentsModel> getStudentByHash(string studentHash)
        {
            var studentsDTO = studentsRepo.getStudentByHash(studentsRepo.getStudentHash(studentHash));
            StudentsModel studentsModel = new StudentsModel(studentsDTO);
            return new KeyValuePair<bool, StudentsModel>(true, studentsModel);
        }

        public KeyValuePair<bool, string> delStudentByHash(string studentHash)
        {
            return studentsRepo.delStudentByHash(studentsRepo.getStudentHash(studentHash));
        }

        public KeyValuePair<bool, QueryResultModel> getStudentsByQuery(StudentsQueryModel studentsQueryModel)
        {
            var studentsDTOList = studentsRepo.getStudentsByQuery(studentsQueryModel);
            List<StudentsModel> students = StudentsModel.cloneDTOToModel(studentsDTOList);
            int total = studentsRepo.getTotalStudentsByQuery(studentsQueryModel);
            int totalPages = (int) Math.Ceiling((double) total / studentsQueryModel.pageSize);
            QueryResultModel studentsQueryResultModel = new QueryResultModel
            {
                totalNumber = total,
                totalPages = totalPages,
                pageNumber = studentsQueryModel.page,
                pageSize = studentsQueryModel.pageSize,
                students = students
            };
            return new KeyValuePair<bool, QueryResultModel>(true, studentsQueryResultModel);
        }
    }
}