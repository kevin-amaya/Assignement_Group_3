using EnrollmentSystem.Models;

namespace EnrollmentSystem.Services
{
     public interface StudentService
    {
        KeyValuePair<bool, string> insertStudent(StudentsQueryModel studentsQueryModel);
        KeyValuePair<bool, string> updateStudentByHash(StudentsQueryModel studentsQueryModel);
        KeyValuePair<bool, StudentsModel> getStudentByHash(string studentHash);
        KeyValuePair<bool, string> delStudentByHash(string studentHash);
        KeyValuePair<bool, QueryResultModel> getStudentsByQuery(StudentsQueryModel studentsQueryModel);
    }
}