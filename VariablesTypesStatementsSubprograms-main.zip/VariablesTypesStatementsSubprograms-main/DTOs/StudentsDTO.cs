namespace EnrollmentSystem.DTOs
{
    public class StudentsDTO
    {
        public string id { get; set; } = string.Empty;
        public string name { get; set; } = string.Empty;
        public string birthDay { get; set; } = string.Empty;
        public string gender { get; set; } = string.Empty;
        public string program { get; set; } = string.Empty;
        public int currentSemester { get; set; } = 0;
        public int numberOfCourses { get; set; } = 0;
        public double previousGPA { get; set; } = 0.0;
    }
}
