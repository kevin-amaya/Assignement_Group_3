from pathlib import Path
import shutil
import subprocess
import sys


def main() -> int:
    project_file = Path(__file__).resolve().parent / "VariablesTypesStatementsSubprograms.csproj"
    if not project_file.is_file():
        print(f"Project file not found: {project_file}", file=sys.stderr)
        return 1

    dotnet = shutil.which("dotnet")
    if dotnet is None:
        print("The .NET CLI ('dotnet') was not found on PATH.", file=sys.stderr)
        return 127

    project_dir = project_file.parent
    build = subprocess.run(
        [dotnet, "build", str(project_file)],
        cwd=project_dir,
        check=False,
    )
    if build.returncode != 0:
        return build.returncode

    run = subprocess.run(
        [dotnet, "run", "--no-build", "--project", str(project_file)],
        cwd=project_dir,
        check=False,
    )
    return run.returncode


if __name__ == "__main__":
    raise SystemExit(main())
