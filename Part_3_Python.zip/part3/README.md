# Part 3 Python enrollment

Run `python enrollment.py` with Python 3.10 or later. Open the local login URL
printed by the server. The classroom demonstration login is the same as in the
Part 2 handoff. Records and sessions reset on restart. No packages are required.

The four files in `wwwroot` are reused unchanged from the November 16 C# handoff.
The Python server uses the handoff's API routes and response format.

Run `python check_parity.py` to compare against `CSharp_contract_results.json`.
It starts a local Python server, replays the recorded requests and saves actual
results in `Python_contract_results.json`. It compares JSON values, exact
message text, HTTP status codes, browser file hashes, and restart behavior.
The future birth date fixture is refreshed to stay in the future. The recorded
C# reference file is preserved as supplied.
