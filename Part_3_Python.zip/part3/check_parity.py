"""Replay the recorded C# handoff checks against a local Python server."""

import argparse
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from hashlib import sha256
from http.cookiejar import CookieJar
import json
from pathlib import Path
from threading import Thread
from urllib.error import HTTPError
from urllib.request import HTTPCookieProcessor, Request, build_opener

from enrollment import EnrollmentServer


@contextmanager
def test_server(port=0):
    with EnrollmentServer(("127.0.0.1", port)) as server:
        server.quiet = True
        worker = Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            yield server.server_port
        finally:
            server.shutdown()
            worker.join()


def run_case(case, port, client):
    body = None
    if "raw_request" in case:
        body = case["raw_request"].encode("utf-8")
    elif case.get("request") is not None:
        body = json.dumps(case["request"]).encode("utf-8")
    headers = {"Content-Type": "application/json"} if body is not None else {}
    request = Request(f"http://127.0.0.1:{port}{case['path']}", data=body,
                      method=case["method"], headers=headers)
    try:
        with client.open(request, timeout=5) as response:
            status, result = response.status, response.read()
    except HTTPError as response:
        status, result = response.code, response.read()
        response.close()
    if case["kind"] == "asset":
        actual = {"bytes": len(result), "sha256": sha256(result).hexdigest()}
        expected = {key: case[key] for key in actual}
    else:
        try:
            actual = json.loads(result)
        except ValueError:
            actual = result.decode("utf-8", errors="replace")
        expected = case["response"]
    return {"id": case["id"], "name": case["name"], "status": status,
            "actual": actual, "passed": status == case["status"] and actual == expected}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, default=Path(__file__).with_name("CSharp_contract_results.json"))
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("Python_contract_results.json"))
    args = parser.parse_args()
    reference = json.loads(args.reference.read_text(encoding="utf-8-sig"))
    cases = reference["cases"]
    # Move the time-sensitive fixture to tomorrow so it still tests future DOBs.
    reference_tomorrow = (date.fromisoformat(reference["started_utc"][:10]) + timedelta(days=1)).isoformat()
    tomorrow = (datetime.now(timezone.utc).date() + timedelta(days=1)).isoformat()
    refreshed = []
    for case in cases:
        if case["name"] == f"Invalid date {reference_tomorrow}":
            case["request"]["birthDay"] = tomorrow
            case["name"] = f"Invalid date {tomorrow}"
            refreshed.append(case["id"])
    restart = next(index for index, case in enumerate(cases) if case["name"] == "Restart requires login")
    client = build_opener(HTTPCookieProcessor(CookieJar()))
    with test_server() as port:
        results = [run_case(case, port, client) for case in cases[:restart]]
    # Restart on the same address and keep the old cookie to test invalidation.
    with test_server(port):
        results.extend(run_case(case, port, client) for case in cases[restart:])
    passed = sum(result["passed"] for result in results)
    report = {"reference": args.reference.name, "refreshed_date_cases": refreshed, "checks": len(results),
              "passed": passed, "failed": len(results) - passed, "cases": results}
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"{passed}/{len(results)} checks matched the recorded C# output.")
    for result in results:
        if not result["passed"]:
            print(f"{result['id']} {ascii(result['name'])}: {result['status']} {ascii(result['actual'])}")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
