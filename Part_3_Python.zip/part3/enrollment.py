"""Local staff enrollment prototype using the Part 2 browser files and API contract."""

import argparse
from dataclasses import asdict, dataclass
from datetime import date, datetime, timezone
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import secrets
from threading import Lock
from time import monotonic
from urllib.parse import parse_qs, urlsplit


ASSETS = {
    "/StudentsLogin.html": "text/html; charset=utf-8",
    "/StudentsManagement.html": "text/html; charset=utf-8",
    "/enrollment.js": "text/javascript; charset=utf-8",
    "/enrollment.css": "text/css; charset=utf-8",
}
TEXT_FIELDS = {
    "firstName": "First name", "lastName": "Last name",
    "gender": "Gender", "program": "Program",
}
INT_MAX = 2**31 - 1
SESSION_SECONDS = 8 * 60 * 60
SESSION_COOKIE = "python_staff_session"
INVALID_REQUEST = "Invalid request data."
STUDENT_MISSING = "Student not found."


class RequestError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def invalid_request():
    return RequestError(400, INVALID_REQUEST)


def parse_int(value):
    if not re.fullmatch(r"[+-]?[0-9]+", value.strip()):
        raise invalid_request()
    try:
        number = int(value)
    except ValueError:
        raise invalid_request() from None
    if not -INT_MAX - 1 <= number <= INT_MAX:
        raise invalid_request()
    return number


def typed_fields(body, field_types):
    # JSON keys are case-insensitive in the C# input model. Values still need
    # explicit runtime checks here. A Python bool cannot stand in for an int.
    lower_keys = {key.lower(): value for key, value in body.items()}
    values = {}
    for name, allowed in field_types.items():
        value = lower_keys.get(name.lower())
        if value is not None and type(value) not in allowed:
            raise invalid_request()
        if allowed == (int,) and value is not None and not -INT_MAX - 1 <= value <= INT_MAX:
            raise invalid_request()
        values[name] = value
    return values


@dataclass
class Student:
    id: int
    first_name: str
    last_name: str
    birth_day: str
    gender: str
    program: str
    current_semester: int
    number_of_courses: int
    previous_gpa: float

    def snapshot(self):
        # Keep Python names in the class but use the exact Part 2 JSON keys.
        return {
            "id": self.id,
            "firstName": self.first_name,
            "lastName": self.last_name,
            "name": self.name,
            "birthDay": self.birth_day,
            "gender": self.gender,
            "program": self.program,
            "currentSemester": self.current_semester,
            "numberOfCourses": self.number_of_courses,
            "previousGPA": self.previous_gpa,
        }

    @property
    def name(self):
        return f"{self.first_name} {self.last_name}"


def validate_student(values, student_id):
    # Validate a complete candidate before changing the stored record.
    text = {}
    for field, label in TEXT_FIELDS.items():
        value = (values[field] or "").strip()
        if not 1 <= len(value.encode("utf-16-le", errors="surrogatepass")) // 2 <= 100:
            raise RequestError(400, f"{label} must contain 1 to 100 characters.")
        text[field] = value

    birthday = values["birthDay"] or ""
    try:
        if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", birthday):
            raise ValueError("Date needs YYYY-MM-DD format")
        if date.fromisoformat(birthday) > datetime.now(timezone.utc).date():
            raise ValueError("Future date")
    except ValueError:
        raise RequestError(400, "Date of birth must be a valid date in YYYY-MM-DD format and cannot be in the future.") from None

    semester = values["currentSemester"]
    if semester is None or semester < 1:
        raise RequestError(400, "Semester must be a whole number of 1 or greater.")
    courses = values["numberOfCourses"]
    if courses is None or courses < 0:
        raise RequestError(400, "Number of courses must be a whole number of 0 or greater.")
    gpa = values["previousGPA"]
    if gpa is None or not 0 <= gpa <= 4:
        raise RequestError(400, "GPA must be a number between 0.0 and 4.0.")
    return Student(student_id, text["firstName"], text["lastName"], birthday,
                   text["gender"], text["program"], semester, courses, float(gpa))


class StudentStore:
    def __init__(self):
        self.students: list[Student] = []
        self.students_by_id: dict[int, Student] = {}
        self.next_id = 1001
        self.lock = Lock()

    def add_student(self, values):
        with self.lock:
            student = validate_student(values, self.next_id)
            self.next_id += 1
            self.students.append(student)
            self.students_by_id[student.id] = student
            return student.id

    def update_student(self, student_id, values):
        with self.lock:
            stored_student = self.find_student(student_id)
            candidate = validate_student(values, student_id)
            # The list and the lookup share this object. Both see the edit.
            for field, value in asdict(candidate).items():
                if field != "id":
                    setattr(stored_student, field, value)

    def find_student(self, student_id):
        # Call this while holding the store lock.
        student = self.students_by_id.get(student_id)
        if student is None:
            raise RequestError(404, STUDENT_MISSING)
        return student

    def get_student(self, student_id):
        with self.lock:
            return self.find_student(student_id).snapshot()

    def delete_student(self, student_id):
        with self.lock:
            student = self.find_student(student_id)
            self.students.remove(student)
            del self.students_by_id[student_id]

    def list_students(self, name, page, page_size):
        with self.lock:
            matching = [student for student in self.students if name in student.name]
            total = len(matching)
            pages = (total + page_size - 1) // page_size
            effective_page = min(page, pages) if pages else 1
            start = (effective_page - 1) * page_size
            return {
                "totalNumber": total, "totalPages": pages, "pageNumber": effective_page,
                "pageSize": page_size,
                "students": [student.snapshot() for student in matching[start:start + page_size]],
            }


class EnrollmentServer(ThreadingHTTPServer):
    def __init__(self, address):
        super().__init__(address, EnrollmentHandler)
        self.store = StudentStore()
        self.sessions = {}
        self.session_lock = Lock()
        self.web_root = Path(__file__).resolve().parent / "wwwroot"

    def start_session(self):
        token = secrets.token_urlsafe(32)
        now = monotonic()
        with self.session_lock:
            self.sessions = {key: end for key, end in self.sessions.items() if end > now}
            self.sessions[token] = now + SESSION_SECONDS
        return token

    def is_signed_in(self, token):
        with self.session_lock:
            return self.sessions.get(token, 0) > monotonic()

    def end_session(self, token):
        with self.session_lock:
            self.sessions.pop(token, None)


class EnrollmentHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_PUT(self):
        self.dispatch("PUT")

    def do_DELETE(self):
        self.dispatch("DELETE")

    def dispatch(self, method):
        try:
            url = urlsplit(self.path)
            if method == "GET" and url.path == "/":
                self.respond(302, headers={"Location": "/StudentsLogin.html"})
            elif method == "GET" and url.path in ASSETS:
                file = self.server.web_root / url.path[1:]
                self.respond(200, file.read_bytes(), {"Content-Type": ASSETS[url.path]})
            elif method == "POST" and url.path.lower() == "/api/login":
                self.login()
            elif url.path.lower().startswith(("/api/students", "/api/login/")):
                self.staff_request(method, url)
            else:
                self.respond(404)
        except RequestError as error:
            self.respond_json(error.status, False, str(error))

    def respond(self, status, payload=b"", headers=None):
        self.send_response(status)
        self.send_header("Content-Length", str(len(payload)))
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        if payload:
            self.wfile.write(payload)

    def respond_json(self, status, success, value, headers=None):
        body = json.dumps({"Key": success, "Value": value}, ensure_ascii=True).encode("utf-8")
        self.respond(status, body, {"Content-Type": "application/json; charset=utf-8", **(headers or {})})

    def read_object(self):
        try:
            if self.headers.get_content_type() != "application/json":
                raise ValueError("Expected JSON")
            length = int(self.headers.get("Content-Length", "0"))
            if not 1 <= length <= 1_048_576:
                raise ValueError("Invalid body length")
            body = json.loads(self.rfile.read(length), parse_constant=self.reject_constant)
        except (ValueError, UnicodeError):
            raise invalid_request() from None
        if not isinstance(body, dict):
            raise invalid_request()
        return body

    @staticmethod
    def reject_constant(value):
        raise ValueError(f"Invalid JSON constant {value}")

    def session_token(self):
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
        except CookieError:
            return ""
        entry = cookie.get(SESSION_COOKIE)
        return entry.value if entry else ""

    def login(self):
        body = typed_fields(self.read_object(), {"username": (str,), "password": (str,)})
        # Same demo account as the local C# prototype.
        if body["username"] != "admin" or body["password"] != "admin":
            raise RequestError(401, "Invalid username or password.")
        self.server.end_session(self.session_token())
        token = self.server.start_session()
        self.respond_json(200, True, "Login successful.", {
            "Set-Cookie": f"{SESSION_COOKIE}={token}; Path=/; HttpOnly; SameSite=Lax",
        })

    def staff_request(self, method, url):
        token = self.session_token()
        if not self.server.is_signed_in(token):
            raise RequestError(401, "Please sign in.")
        path = url.path.rstrip("/").lower()
        if method == "POST" and path == "/api/login/logout":
            self.server.end_session(token)
            self.respond_json(200, True, "Logout successful.", {
                "Set-Cookie": f"{SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax",
            })
            return
        match = re.fullmatch(r"/api/students(?:/([^/]+))?", path)
        if match is None:
            self.respond(404)
            return
        student_id = parse_int(match.group(1)) if match.group(1) is not None else None
        self.student_request(method, student_id, url.query)

    def student_request(self, method, student_id, query_string):
        store = self.server.store
        if method == "GET":
            if student_id is None:
                query = {key.lower(): values[0] for key, values in
                         parse_qs(query_string, keep_blank_values=True).items()}
                page = parse_int(query.get("page", "1"))
                page_size = parse_int(query.get("pagesize", "10"))
                if page < 1 or not 1 <= page_size <= 100:
                    raise RequestError(400, "Page must be 1 or greater and page size must be between 1 and 100.")
                value = store.list_students(query.get("name", ""), page, page_size)
            else:
                value = store.get_student(student_id)
        elif method == "DELETE" and student_id is not None:
            store.delete_student(student_id)
            value = "Record removed."
        elif (method == "POST" and student_id is None) or (method == "PUT" and student_id is not None):
            values = typed_fields(self.read_object(), {
                **{name: (str,) for name in TEXT_FIELDS}, "birthDay": (str,),
                "currentSemester": (int,), "numberOfCourses": (int,), "previousGPA": (int, float),
            })
            if student_id is None:
                value = f"Added Student ID: {store.add_student(values)}"
            else:
                store.update_student(student_id, values)
                value = "Record updated."
        else:
            self.respond(405)
            return
        self.respond_json(200, True, value)

    def log_message(self, format, *args):
        if not getattr(self.server, "quiet", False):
            super().log_message(format, *args)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=5001)
    args = parser.parse_args()
    with EnrollmentServer(("127.0.0.1", args.port)) as server:
        print(f"http://127.0.0.1:{server.server_port}/StudentsLogin.html", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
